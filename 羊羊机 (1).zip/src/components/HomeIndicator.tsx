export function HomeIndicator({ onHome, dark = false }: { onHome: () => void; dark?: boolean }) {
  // Completely removed because it sits over input elements and blocks user taps
  return null;
}
