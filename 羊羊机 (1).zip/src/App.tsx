import { useEffect } from 'react';
import { PhoneShell } from './components/PhoneShell';
import { usePersistedState } from './usePersistedState';
import { applyTheme } from './themes';

export default function App() {
  const { state, updateSettings, replaceState } = usePersistedState();

  useEffect(() => {
    applyTheme(state.settings.themeId);
  }, [state.settings.themeId]);

  useEffect(() => {
    const settings = state.settings;
    if (!settings.autoBackupEnabled) return;

    const freq = settings.autoBackupFrequency || 'daily';
    const lastBackup = settings.lastAutoBackupTs || 0;
    const now = Date.now();

    let threshold = 24 * 60 * 60 * 1000; // 每天
    if (freq === 'five_days') {
      threshold = 5 * 24 * 60 * 60 * 1000; // 每五天
    } else if (freq === 'half_month') {
      threshold = 15 * 24 * 60 * 60 * 1000; // 半个月 (15天)
    } else if (freq === 'monthly') {
      threshold = 30 * 24 * 60 * 60 * 1000; // 每月 (30天)
    }

    if (now - lastBackup >= threshold) {
      import('./store').then(({ saveAutoBackup }) => {
        const success = saveAutoBackup(state);
        if (success) {
          updateSettings({ lastAutoBackupTs: now });
        }
      });
    }
  }, [state.settings.autoBackupEnabled, state.settings.autoBackupFrequency, state.settings.lastAutoBackupTs]);

  // Automatically treat installed PWA standalone mode as full screen
  const isPwa = typeof window !== 'undefined' && (
    (window.navigator as any).standalone || 
    window.matchMedia('(display-mode: standalone)').matches
  );
  const isFullscreen = !!(state.settings.fullscreenMode || isPwa);

  return (
    <div className={`h-full w-full flex items-center justify-center bg-black relative ${isFullscreen ? 'p-0' : 'p-0 sm:p-4'}`}>
      {/* device frame on larger screens; full-bleed on phones */}
      <div 
        className={
          isFullscreen
            ? "relative w-full h-full overflow-hidden bg-black flex flex-col"
            : "relative w-full h-[100dvh] transition-all duration-500 ease-in-out overflow-hidden bg-black flex flex-col pt-[calc(env(safe-area-inset-top,10px)+4px)] pb-[env(safe-area-inset-bottom,10px)] sm:pt-0 sm:pb-0 sm:h-[860px] sm:max-h-[92vh] sm:w-[420px] sm:rounded-[52px] sm:border-[10px] sm:border-black sm:shadow-2xl"
        }
      >
        <PhoneShell state={state} settings={state.settings} updateSettings={updateSettings} replaceState={replaceState} />
      </div>
    </div>
  );
}
