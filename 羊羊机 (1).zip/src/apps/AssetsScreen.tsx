import React, { useRef, useState } from 'react';
import { 
  Music as MusicIcon, 
  Image as ImageIcon, 
  Plus, 
  Smile, 
  Upload, 
  Trash2, 
  Link, 
  ChevronRight, 
  Download, 
  FolderPlus, 
  Users, 
  X, 
  Sparkles, 
  Check, 
  CheckSquare, 
  Square,
  FileCode,
  Edit2
} from 'lucide-react';
import { AppScreen } from '../components/AppScreen';
import type { MusicTrack, AlbumImage, AppSettings, ExpressionPack, ExpressionItem, Character } from '../types';
import { uid, fileToDataUrl } from '../utils';

export function AssetsScreen({
  music,
  album,
  onAddMusic,
  onAddAlbum,
  onClearMusic,
  onClearAlbum,
  onBack,
  settings,
  updateSettings,
}: {
  music: MusicTrack[];
  album: AlbumImage[];
  onAddMusic: (t: MusicTrack) => void;
  onAddAlbum: (i: AlbumImage) => void;
  onClearMusic: () => void;
  onClearAlbum: () => void;
  onBack: () => void;
  settings: AppSettings;
  updateSettings: (patch: Partial<AppSettings>) => void;
}) {
  const musicRef = useRef<HTMLInputElement>(null);
  const albumRef = useRef<HTMLInputElement>(null);
  const jsonImportRef = useRef<HTMLInputElement>(null);
  const bulkImageRef = useRef<HTMLInputElement>(null);

  // Expression Pack UI states
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newPackName, setNewPackName] = useState('');
  const [newPackDesc, setNewPackDesc] = useState('');
  const [activePackId, setActivePackId] = useState<string | null>(null);
  const [showLinkImportModal, setShowLinkImportModal] = useState(false);
  const [pastedLinksText, setPastedLinksText] = useState('');

  const packs = settings.expressionPacks || [];

  const pickMusic = async (files: FileList | null) => {
    if (!files) return;
    for (const f of Array.from(files)) {
      if (!f.type.startsWith('audio')) continue;
      onAddMusic({ id: uid(), name: f.name.replace(/\.[^.]+$/, ''), url: URL.createObjectURL(f), duration: 0 });
    }
  };

  const pickAlbum = async (files: FileList | null) => {
    if (!files) return;
    for (const f of Array.from(files)) {
      if (!f.type.startsWith('image')) continue;
      const url = await fileToDataUrl(f);
      onAddAlbum({ id: uid(), url });
    }
  };

  // Create empty expression pack
  const handleCreatePack = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newPackName.trim()) return;

    const newPack: ExpressionPack = {
      id: uid(),
      name: newPackName.trim(),
      description: newPackDesc.trim(),
      expressions: [],
      characterConnections: [],
      isActive: true
    };

    updateSettings({
      expressionPacks: [...packs, newPack]
    });

    setNewPackName('');
    setNewPackDesc('');
    setShowCreateModal(false);
    setActivePackId(newPack.id); // Open it immediately
  };

  // Import Expression Pack JSON
  const handleJsonImport = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const rawJson = event.target?.result as string;
        const parsed = JSON.parse(rawJson);
        if (!parsed.name) {
          alert('无效的表情包：JSON文件必须包含 name 字段');
          return;
        }

        const rawExprs = Array.isArray(parsed.expressions) ? parsed.expressions : [];
        const expressions: ExpressionItem[] = rawExprs.map((ex: any) => ({
          id: uid(),
          name: ex.name || '表情',
          url: ex.url || '',
          isDynamic: ex.url ? (ex.url.includes('image/gif') || ex.url.includes('image/webp') || ex.url.endsWith('.gif')) : false
        })).filter(ex => ex.url);

        const newPack: ExpressionPack = {
          id: uid(),
          name: parsed.name,
          description: parsed.description || '',
          expressions,
          characterConnections: parsed.characterConnections || [],
          isActive: true
        };

        updateSettings({
          expressionPacks: [...packs, newPack]
        });
        alert(`成功导入表情包「${newPack.name}」，共 ${newPack.expressions.length} 个表情！`);
      } catch (err) {
        alert('解析表情包 JSON 失败: ' + (err as Error).message);
      }
    };
    reader.readAsText(file);
    e.target.value = ''; // Reset
  };

  // Download template JSON
  const downloadTemplate = () => {
    const template = {
      name: "萌宠表情包",
      description: "导入该文件会加载一些默认简易手绘表情",
      expressions: [
        { 
          name: "开心羊羊", 
          url: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' viewBox='0 0 100 100'><rect width='100' height='100' rx='20' fill='%23EEF2F6'/><circle cx='50' cy='50' r='35' fill='%23FFFFFF' stroke='%236366F1' stroke-width='4'/><circle cx='40' cy='45' r='4' fill='%234F46E5'/><circle cx='60' cy='45' r='4' fill='%234F46E5'/><path d='M40,60 Q50,75 60,60' stroke='%234F46E5' stroke-width='4' fill='none' stroke-linecap='round'/></svg>" 
        },
        { 
          name: "大哭羊羊", 
          url: "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='120' height='120' viewBox='0 0 100 100'><rect width='100' height='100' rx='20' fill='%23EEF2F6'/><circle cx='50' cy='50' r='35' fill='%23FFFFFF' stroke='%233B82F6' stroke-width='4'/><circle cx='40' cy='45' r='4' fill='%231D4ED8'/><circle cx='60' cy='45' r='4' fill='%231D4ED8'/><path d='M42,65 Q50,55 58,65' stroke='%231D4ED8' stroke-width='4' fill='none' stroke-linecap='round'/><path d='M40,50 L40,60 M60,50 L60,60' stroke='%2360A5FA' stroke-width='3' fill='none'/></svg>" 
        }
      ]
    };
    const blob = new Blob([JSON.stringify(template, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = "expression_pack_template.json";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Active pack object
  const activePack = packs.find(p => p.id === activePackId);

  // Bulk add images to the active pack
  const handleBulkImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!activePack || !e.target.files || e.target.files.length === 0) return;

    const newExprs: ExpressionItem[] = [];
    for (const f of Array.from(e.target.files) as File[]) {
      const url = await fileToDataUrl(f);
      const isDynamic = f.type === 'image/gif' || f.type === 'image/webp' || f.name.toLowerCase().endsWith('.gif') || f.name.toLowerCase().endsWith('.webp');
      const name = f.name.replace(/\.[^.]+$/, ''); // Remove extension

      newExprs.push({
        id: uid(),
        name: name || '表情',
        url,
        isDynamic
      });
    }

    const updatedPacks = packs.map(p => {
      if (p.id === activePack.id) {
        return {
          ...p,
          expressions: [...p.expressions, ...newExprs]
        };
      }
      return p;
    });

    updateSettings({ expressionPacks: updatedPacks });
    e.target.value = ''; // Reset
  };

  // Bulk import expression items via text link lines
  const handleImportTextLinks = (e: React.FormEvent) => {
    e.preventDefault();
    if (!activePack || !pastedLinksText.trim()) return;

    const lines = pastedLinksText.split('\n');
    const newExprs: ExpressionItem[] = [];

    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed) continue;

      let name = '';
      let url = '';
      // Split by "：" (Chinese full-width colon) or ":" (English colon) or whitespace/comma
      const colonIdx = trimmed.indexOf('：') !== -1 ? trimmed.indexOf('：') : trimmed.indexOf(':');
      if (colonIdx !== -1) {
        name = trimmed.substring(0, colonIdx).trim();
        url = trimmed.substring(colonIdx + 1).trim();
      } else {
        // Try to search for http/https url on the line
        const urlMatch = trimmed.match(/https?:\/\/[^\s]+/);
        if (urlMatch) {
          url = urlMatch[0];
          name = trimmed.replace(url, '').replace(/[:：]/g, '').trim();
        }
      }

      if (url && url.startsWith('http')) {
        const isDynamic = url.toLowerCase().includes('.gif') || url.toLowerCase().includes('.webp') || url.toLowerCase().includes('.apng');
        newExprs.push({
          id: uid(),
          name: name || '表情',
          url,
          isDynamic
        });
      }
    }

    if (newExprs.length === 0) {
      alert('未检测到任何有效的图片/动图链接。请确保输入格式为：名称：链接');
      return;
    }

    const updatedPacks = packs.map(p => {
      if (p.id === activePack.id) {
        return {
          ...p,
          expressions: [...p.expressions, ...newExprs]
        };
      }
      return p;
    });

    updateSettings({ expressionPacks: updatedPacks });
    setPastedLinksText('');
    setShowLinkImportModal(false);
    alert(`成功导入 ${newExprs.length} 个自定义表情！`);
  };

  // Delete individual expression from active pack
  const handleDeleteExpression = (exprId: string) => {
    if (!activePack) return;
    const updatedPacks = packs.map(p => {
      if (p.id === activePack.id) {
        return {
          ...p,
          expressions: p.expressions.filter(ex => ex.id !== exprId)
        };
      }
      return p;
    });
    updateSettings({ expressionPacks: updatedPacks });
  };

  // Toggle Character connection to active pack
  const handleToggleConnection = (charId: string) => {
    if (!activePack) return;
    const currentConnections = activePack.characterConnections || [];
    const isConnected = currentConnections.includes(charId);
    const nextConnections = isConnected 
      ? currentConnections.filter(id => id !== charId) 
      : [...currentConnections, charId];

    const updatedPacks = packs.map(p => {
      if (p.id === activePack.id) {
        return {
          ...p,
          characterConnections: nextConnections
        };
      }
      return p;
    });
    updateSettings({ expressionPacks: updatedPacks });
  };

  // Delete entire pack
  const handleDeletePack = (packId: string) => {
    if (!confirm('确认要彻底删除该表情包吗？此操作不可撤销。')) return;
    updateSettings({
      expressionPacks: packs.filter(p => p.id !== packId)
    });
    setActivePackId(null);
  };

  return (
    <AppScreen title="本地资源" onBack={onBack}>
      <div className="text-[12px] txt-faint mb-4 leading-relaxed">
        导入和管理本地媒体文件。音乐可在桌面小组件与播放器中使用；图片出现在相册中；自定义表情包可绑定到对应角色中，供聊天使用。
      </div>

      {/* 1. MUSIC SECTION */}
      <Section
        title="本地音乐"
        icon={<MusicIcon size={16} />}
        count={music.length}
        onAdd={() => musicRef.current?.click()}
        onClear={onClearMusic}
        emptyText="还没有音乐文件"
      >
        {music.map((t) => (
          <div key={t.id} className="px-4 py-2.5 flex items-center gap-3 border-t border-[var(--border)] first:border-t-0">
            <MusicIcon size={15} className="txt-dim shrink-0" />
            <div className="flex-1 min-w-0 text-[14px] truncate">{t.name}</div>
          </div>
        ))}
      </Section>

      {/* 2. ALBUM IMAGES SECTION */}
      <div className="mt-5">
        <Section
          title="相册图片"
          icon={<ImageIcon size={16} />}
          count={album.length}
          onAdd={() => albumRef.current?.click()}
          onClear={onClearAlbum}
          emptyText="还没有图片"
        >
          {album.length > 0 && (
            <div className="p-3 grid grid-cols-4 gap-1.5 border-t border-[var(--border)]">
              {album.map((im) => (
                <img key={im.id} src={im.url} alt="" className="w-full aspect-square object-cover rounded-lg" />
              ))}
            </div>
          )}
        </Section>
      </div>

      {/* 3. EXPRESSION PACKS SECTION */}
      <div className="mt-5">
        <div className="glass rounded-2xl overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3">
            <div className="flex items-center gap-2 font-medium">
              <Smile size={16} className="text-amber-400" />
              <span>自定义表情包</span>
              <span className="txt-faint text-[12px]">({packs.length})</span>
            </div>
            <div className="flex items-center gap-1.5">
              <button 
                onClick={() => setShowCreateModal(true)} 
                className="tap w-8 h-8 rounded-full glass flex items-center justify-center txt-accent"
                title="新建表情包"
              >
                <Plus size={16} />
              </button>
              <button 
                onClick={() => jsonImportRef.current?.click()} 
                className="tap w-8 h-8 rounded-full glass flex items-center justify-center text-amber-400"
                title="导入表情包 JSON"
              >
                <Upload size={14} />
              </button>
              <button 
                onClick={downloadTemplate} 
                className="tap w-8 h-8 rounded-full glass flex items-center justify-center text-neutral-400"
                title="下载导入模板"
              >
                <Download size={14} />
              </button>
            </div>
          </div>

          {packs.length === 0 ? (
            <div className="px-4 pb-4 pt-1 txt-faint text-[12px] leading-relaxed">
              尚未添加任何表情包。您可以点击右上角：<br/>
              • <strong className="txt-accent">加号</strong> 创建一个全新表情包并批量导入图片<br/>
              • <strong className="text-amber-400">导入图标</strong> 从JSON备份直接导入<br/>
              • <strong className="text-neutral-400">下载图标</strong> 获得标准的JSON模版
            </div>
          ) : (
            <div className="border-t border-[var(--border)] divide-y divide-[var(--border)]">
              {packs.map((p) => {
                const cover = p.expressions?.[0]?.url;
                const charCount = p.characterConnections?.length || 0;
                return (
                  <div 
                    key={p.id} 
                    onClick={() => setActivePackId(p.id)}
                    className="p-3.5 flex items-center gap-3 hover:bg-white/5 cursor-pointer transition-colors"
                  >
                    {cover ? (
                      <img src={cover} alt="" className="w-12 h-12 rounded-lg object-cover bg-neutral-900 border border-[var(--border)]" />
                    ) : (
                      <div className="w-12 h-12 rounded-lg bg-neutral-900 border border-[var(--border)] flex items-center justify-center text-amber-500/55">
                        <Smile size={24} />
                      </div>
                    )}

                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-[14px] flex items-center gap-1.5">
                        <span>{p.name}</span>
                        {p.expressions.some(e => e.isDynamic) && (
                          <span className="text-[9px] px-1 py-0.5 rounded bg-amber-500/20 text-amber-400 font-bold scale-90">GIF/WebP</span>
                        )}
                      </div>
                      <div className="text-[11px] txt-dim truncate mt-0.5">
                        {p.description || '无描述'}
                      </div>
                      <div className="flex items-center gap-3 mt-1.5 text-[10px] text-neutral-400">
                        <span className="bg-neutral-800/60 px-1.5 py-0.5 rounded-md">📦 {p.expressions.length} 个表情</span>
                        <span className={`px-1.5 py-0.5 rounded-md ${charCount > 0 ? 'bg-indigo-500/15 text-indigo-300' : 'bg-neutral-800/40 text-neutral-500'}`}>
                          🔗 {charCount > 0 ? `关联 ${charCount} 个角色` : '未关联任何角色'}
                        </span>
                      </div>
                    </div>

                    <ChevronRight size={16} className="text-neutral-500 shrink-0" />
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      {/* Hidden Files Selectors */}
      <input ref={musicRef} type="file" accept="audio/*" multiple className="hidden" onChange={(e) => pickMusic(e.target.files)} />
      <input ref={albumRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => pickAlbum(e.target.files)} />
      <input ref={jsonImportRef} type="file" accept=".json" className="hidden" onChange={handleJsonImport} />
      <input ref={bulkImageRef} type="file" accept="image/*" multiple className="hidden" onChange={handleBulkImageUpload} />

      {/* CREATE NEW PACK MODAL */}
      {showCreateModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-black/70" onClick={() => setShowCreateModal(false)} />
          <form 
            onSubmit={handleCreatePack}
            className="relative w-full max-w-sm glass-strong rounded-2xl p-5 border border-[var(--border)] shadow-2xl animate-sheet-up"
          >
            <div className="flex justify-between items-center mb-4">
              <h3 className="font-title text-[16px] flex items-center gap-1.5">
                <FolderPlus size={18} className="text-amber-400" />
                <span>新建表情包</span>
              </h3>
              <button type="button" onClick={() => setShowCreateModal(false)} className="tap text-neutral-400">
                <X size={18} />
              </button>
            </div>

            <div className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-bold text-neutral-400 mb-1">表情包名称</label>
                <input 
                  type="text" 
                  value={newPackName}
                  onChange={(e) => setNewPackName(e.target.value)}
                  placeholder="例如：乖巧羊羊"
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-[13px] outline-none focus:border-amber-400"
                  required
                  autoFocus
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-neutral-400 mb-1">描述 (选填)</label>
                <textarea 
                  value={newPackDesc}
                  onChange={(e) => setNewPackDesc(e.target.value)}
                  placeholder="描述你的表情包特色…"
                  className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-[12px] h-16 outline-none resize-none focus:border-amber-400"
                />
              </div>
            </div>

            <div className="flex gap-3 mt-5">
              <button 
                type="button" 
                onClick={() => setShowCreateModal(false)}
                className="flex-1 bg-neutral-800 py-2.5 rounded-xl text-xs font-bold text-neutral-300 transition-colors"
              >
                取消
              </button>
              <button 
                type="submit" 
                className="flex-1 bg-amber-500 hover:bg-amber-400 text-neutral-950 py-2.5 rounded-xl text-xs font-bold transition-colors"
              >
                确认创建
              </button>
            </div>
          </form>
        </div>
      )}

      {/* EXPRESSION PACK DETAIL OVERLAY */}
      {activePack && (
        <div className="fixed inset-0 z-50 bg-[var(--bg)] flex flex-col animate-fade-in text-left">
          {/* Header */}
          <div className="px-4 py-3 flex items-center justify-between border-b border-[var(--border)] shrink-0">
            <div className="flex items-center gap-1.5 min-w-0">
              <button onClick={() => setActivePackId(null)} className="tap text-[14px] font-medium mr-1 select-none">
                返回
              </button>
              <div className="min-w-0">
                <h2 className="font-title text-[15px] truncate">{activePack.name}</h2>
                <p className="text-[10px] txt-faint truncate">{activePack.description || '自定义表情包'}</p>
              </div>
            </div>

            <div className="flex items-center gap-2">
              <button 
                onClick={() => setShowLinkImportModal(true)}
                className="bg-neutral-800 hover:bg-neutral-700 text-amber-400 px-2.5 py-1 rounded-full text-[11px] font-bold flex items-center gap-1 transition-all border border-amber-500/20"
              >
                <Link size={12} /> 导入文本链接
              </button>
              <button 
                onClick={() => bulkImageRef.current?.click()}
                className="bg-amber-500 hover:bg-amber-400 text-neutral-950 px-2.5 py-1 rounded-full text-[11px] font-bold flex items-center gap-1 transition-all"
              >
                <Plus size={13} /> 批量导入图片
              </button>
              <button 
                onClick={() => handleDeletePack(activePack.id)}
                className="w-8 h-8 rounded-full bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 flex items-center justify-center transition-all"
                title="删除表情包"
              >
                <Trash2 size={14} />
              </button>
            </div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-5">
            {/* 1. Pack Meta Info & Quick Actions */}
            <div className="bg-neutral-900/40 p-3 rounded-2xl border border-white/5 flex flex-col gap-2.5">
              <div>
                <span className="text-[10px] text-neutral-400 uppercase font-bold tracking-wider">表情包说明</span>
                <p className="text-[12px] txt-dim mt-0.5 leading-relaxed">
                  导入的图片将存储在本地。支持静态图片（PNG, JPG, SVG）与动态表情（GIF, WebP, APNG）批量导入。
                </p>
              </div>
            </div>

            {/* 2. CONNECTION MANAGEMENT AREA */}
            <div className="space-y-2">
              <h3 className="font-title text-[12px] text-indigo-300 uppercase font-bold tracking-wider flex items-center gap-1">
                <Users size={14} />
                <span>连接管理 (关联角色)</span>
              </h3>
              <p className="text-[10.5px] text-neutral-400 leading-relaxed">
                勾选角色，将表情包与其建立连接。关联后，不仅您可以发该表情给他们，<strong className="text-amber-400">他们在日常回复时也有概率挑选并发给您</strong>！
              </p>

              {settings.characters && settings.characters.length > 0 ? (
                <div className="grid grid-cols-2 gap-2 pt-1">
                  {settings.characters.map((char) => {
                    const isConnected = activePack.characterConnections?.includes(char.id) || false;
                    return (
                      <button
                        key={char.id}
                        type="button"
                        onClick={() => handleToggleConnection(char.id)}
                        className={`p-2.5 rounded-xl border text-left flex items-center gap-2.5 transition-all cursor-pointer ${
                          isConnected 
                            ? 'bg-indigo-500/10 border-indigo-500/30 text-indigo-100' 
                            : 'bg-neutral-900/40 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                        }`}
                      >
                        {isConnected ? (
                          <CheckSquare size={16} className="text-indigo-400 shrink-0" />
                        ) : (
                          <Square size={16} className="text-neutral-500 shrink-0" />
                        )}
                        {char.avatar ? (
                          <img src={char.avatar} alt="" className="w-6 h-6 rounded-full object-cover bg-neutral-800" />
                        ) : (
                          <div className="w-6 h-6 rounded-full bg-neutral-800 flex items-center justify-center text-[10px] text-neutral-500 font-bold">
                            {char.name[0]}
                          </div>
                        )}
                        <span className="text-[12px] font-semibold truncate flex-1">{char.name}</span>
                      </button>
                    );
                  })}
                </div>
              ) : (
                <div className="bg-neutral-900/20 border border-neutral-800 rounded-xl p-3 text-center text-[11px] text-neutral-500">
                  当前暂无自定义角色，去「角色管理」里新建一个吧！
                </div>
              )}
            </div>

            {/* 3. EXPRESSIONS GRID */}
            <div className="space-y-2">
              <h3 className="font-title text-[12px] text-amber-400 uppercase font-bold tracking-wider flex items-center justify-between">
                <span>表情资源管理 ({activePack.expressions.length})</span>
                {activePack.expressions.length > 0 && (
                  <span className="text-[10px] text-neutral-500 lowercase">在右上角点击“批量导入”增加</span>
                )}
              </h3>

              {activePack.expressions.length === 0 ? (
                <div className="border border-dashed border-neutral-800 rounded-2xl p-10 text-center flex flex-col items-center justify-center gap-2">
                  <div className="w-12 h-12 rounded-full bg-neutral-900 flex items-center justify-center text-amber-500/40">
                    <Smile size={24} />
                  </div>
                  <div className="text-[12px] font-bold text-neutral-400">表情包空空如也</div>
                  <p className="text-[10.5px] text-neutral-500 max-w-[240px] leading-relaxed">
                    点击右上角“<strong className="txt-accent">批量导入图片</strong>”来向包里添加表情，支持多选静态或动画格式。
                  </p>
                </div>
              ) : (
                <div className="grid grid-cols-4 gap-2">
                  {activePack.expressions.map((ex) => (
                    <div 
                      key={ex.id}
                      className="relative rounded-xl border border-neutral-800/60 bg-neutral-950/40 p-1.5 flex flex-col items-center group overflow-hidden"
                    >
                      {/* Delete icon */}
                      <button
                        onClick={() => handleDeleteExpression(ex.id)}
                        className="absolute top-0.5 right-0.5 bg-black/60 hover:bg-red-500 text-white w-5 h-5 rounded-full flex items-center justify-center transition-all opacity-100 sm:opacity-0 group-hover:opacity-100 cursor-pointer shadow-md z-10"
                        title="删除此表情"
                      >
                        <X size={10} />
                      </button>

                      <img 
                        src={ex.url} 
                        alt={ex.name} 
                        className="w-full aspect-square object-contain rounded-lg bg-neutral-900/60" 
                      />
                      <div className="text-[10px] txt-dim truncate max-w-full text-center mt-1 px-0.5">
                        {ex.name}
                      </div>

                      {ex.isDynamic && (
                        <div className="absolute bottom-6 right-1.5 bg-amber-500/80 text-neutral-950 text-[7.5px] px-0.5 rounded font-bold scale-90">
                          GIF
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          {/* TEXT LINK IMPORT MODAL */}
          {showLinkImportModal && (
            <div className="fixed inset-0 z-[110] flex items-center justify-center p-4">
              <div className="absolute inset-0 bg-black/80 backdrop-blur-xs" onClick={() => setShowLinkImportModal(false)} />
              <form 
                onSubmit={handleImportTextLinks}
                className="relative w-full max-w-lg glass-strong rounded-2xl p-5 border border-[var(--border)] shadow-2xl animate-sheet-up flex flex-col max-h-[90vh]"
              >
                <div className="flex justify-between items-center mb-3 shrink-0">
                  <h3 className="font-title text-[15px] flex items-center gap-1.5 font-bold">
                    <Link size={16} className="text-amber-400" />
                    <span>文本链接批量导入</span>
                  </h3>
                  <button type="button" onClick={() => setShowLinkImportModal(false)} className="tap text-neutral-400">
                    <X size={18} />
                  </button>
                </div>

                <p className="text-[11px] text-neutral-400 mb-3 leading-relaxed shrink-0">
                  支持从各种图床（如 PostImg, ImgBB 等）或任意网络图片直接批量导入。每一行格式形如：<strong className="text-amber-400">表情名称：链接地址</strong>。系统会自动识别名称，并智能检测动图格式（如 GIF、WebP）。
                </p>

                <div className="flex items-center justify-between mb-2 shrink-0">
                  <span className="text-[11px] font-bold text-neutral-400">粘贴文本链接列表：</span>
                  <button 
                    type="button"
                    onClick={() => setPastedLinksText(
                      `晕：https://i.postimg.cc/rpq25dnv/mmexport017ce0a0774fd2d336a7bc5531bcfec2-1778089417978.gif\n` +
                      `期待：https://i.postimg.cc/CKwpbZrg/mmexport0635ee024ee8970df9572a4bd7901d84-1778089411591.gif\n` +
                      `幸运：https://i.postimg.cc/k57PWVYq/mmexport0dccdbf185430396d068e07d49009d06-1778089407105.gif\n` +
                      `哼💢：https://i.postimg.cc/JhKVx1Sh/mmexport15370250b5493fa484724ffd9a6f2e06-1778089380734.gif\n` +
                      `欣赏自己：https://i.postimg.cc/5tfW8H7K/mmexport1778089421997.gif\n` +
                      `晚安：https://i.postimg.cc/YStBQ4nZ/mmexport1778089424220.gif\n` +
                      `感冒了：https://i.postimg.cc/Pqdn1L3c/mmexport1778089426339.gif\n` +
                      `无聊：https://i.postimg.cc/6QBxC7jk/mmexport1778089434984.gif\n` +
                      `脏兮兮：https://i.postimg.cc/pdPMK9G0/mmexport1778089437239.gif\n` +
                      `喜欢！：https://i.postimg.cc/yN7C0JQb/mmexport1778089439621.gif\n` +
                      `……：https://i.postimg.cc/qvsdtcwf/mmexport1778089442304.gif\n` +
                      `生气：https://i.postimg.cc/8zRVFdH3/mmexport1778089444561.gif\n` +
                      `惊：https://i.postimg.cc/MGt25WgT/mmexport22cd058eaa6e35ff4d704b42bf4c2fb3-1778089384641.gif\n` +
                      `滑冰：https://i.postimg.cc/KYQSfZCn/mmexport272062cf5454558eb08b42f0ef06131a-1778089370101.gif\n` +
                      `跳跳：https://i.postimg.cc/9f15bWsX/mmexport27e221f7d4e3c5af763e249a62858eee-1778089389385.gif\n` +
                      `出门：https://i.postimg.cc/SKVFdyHr/mmexport30e4b4ea3ee7453e7b5fde403a6b0629-1778089368557.gif\n` +
                      `在路上：https://i.postimg.cc/xdgD50B8/mmexport32075d77edc73c3b1d866d0c7984f93d-1778089382733.gif\n` +
                      `尴尬：https://i.postimg.cc/rpgXj87j/mmexport3cbc1f3e21cdb3fc8fc2b94971c14912-1778089365511.gif\n` +
                      `不想理你：https://i.postimg.cc/k5w3snLg/mmexport3e61c5988820d9964c3dfb1744426fe3-1778089386282.gif\n` +
                      `哦：https://i.postimg.cc/fbMQY3qh/mmexport528837eee253d6158747e9b25e6ee25b-1778089408724.gif\n` +
                      `很晚了：https://i.postimg.cc/NMMhP3wR/mmexport5b953bf3c3a1e64c496a43a3e7c8da8d-1778089361382.gif\n` +
                      `咖啡：https://i.postimg.cc/W33RfBP6/mmexport69bd6d76f250078b844062deb831e414-1778089355961.gif\n` +
                      `开饭！：https://i.postimg.cc/KYmhtKpX/mmexport6e46d336558f9e251867fbb35e3b8236-1778089416343.gif\n` +
                      `看视频：https://i.postimg.cc/CKwpbZrp/mmexport74cdbeb751c46ff3131b1851ea9bbc3c-1778089413346.gif\n` +
                      `累：https://i.postimg.cc/mrVfjbKc/mmexport78f4bb87e3346d6cce51987e554ad2a7-1778089379414.gif\n` +
                      `发呆：https://i.postimg.cc/GpzwKc6L/mmexport79f3c5c3a692ab4e133ed72141544f66-1778089392536.gif\n` +
                      `你的小猫突然出现！：https://i.postimg.cc/g0Gb3wtn/mmexport7a495aa7bf884c5c504c87cacaa1784c-1778089396589.gif\n` +
                      `嗨起来！：https://i.postimg.cc/MTTkrC8R/mmexport7b17d37dc03cfb1eaad3fe88a0934f05-1778089359747.gif\n` +
                      `一起玩吗♡：https://i.postimg.cc/YStBQ4D2/mmexport84d461f63682e66f6ecef953d5212828-1778089402885.gif\n` +
                      `贴贴！：https://i.postimg.cc/PxxGFgkm/mmexport8a7fe7e6f25ada69218da771776c1af1-1778089357963.gif\n` +
                      `嗯嗯：https://i.postimg.cc/0N9176Xk/mmexport8b79c935e97301cee4c02ec36c903c95-1778089404441.gif\n` +
                      `喜欢~：https://i.postimg.cc/FKhX0fCK/mmexport978b2dc4f614f9961ebfed6f3b1af462-1778089398441.gif\n` +
                      `害怕：https://i.postimg.cc/vmXFhQCg/mmexporta4ec853f1f6db561eeeac653b6b39cae-1778089376281.gif\n` +
                      `盯：https://i.postimg.cc/pdPMK9cm/mmexporta80207a874be8dfb82d3e0e43c0717c0-1778089394166.gif\n` +
                      `比心：https://i.postimg.cc/gJJ9BCPy/mmexportb8e7c744016061dea99bdc6f42e2074b-1778089354041.gif\n` +
                      `上网中：https://i.postimg.cc/QMjZcBYd/mmexportc7089fc27e9c2f9c303a5e1a4c1b13e7-1778089399819.gif\n` +
                      `惊喜！是礼物：https://i.postimg.cc/GpzwKc6Y/mmexportca2f96678e261a4cd082ab9677bfffa5-1778089374915.gif\n` +
                      `哼哼哼：https://i.postimg.cc/fb5nCw1w/mmexportd1c14baa443bfa31bd8a0283073da418-1778089391010.gif\n` +
                      `哈哈哈哈哈：https://i.postimg.cc/d0nP6qg9/mmexportda662c2d99d327ef6f244d779bc22c6f-1778089366907.gif\n` +
                      `监督：https://i.postimg.cc/0N9176XR/mmexportdbc4d49161dcb093350157be2591b686-1778089414753.gif\n` +
                      `好无聊：https://i.postimg.cc/43wkPJjc/mmexporte0b655c4c52ee52acb364f894bf6e641-1778089377741.gif\n` +
                      `洗澡🚿：https://i.postimg.cc/Sss0tBp9/mmexporte297a5f75543b4a38dedc788c2006d96-1778089363298.gif\n` +
                      `爱你爱你：https://i.postimg.cc/QMjZcBYD/mmexporte4d76433ece241ec729190c68115de65-1778089410228.gif\n` +
                      `伸懒腰：https://i.postimg.cc/8CwQ41xM/mmexporte51e3beeae710ce2f436713faec7b4fd-1778089372964.gif\n` +
                      `？？？：https://i.postimg.cc/hGKRVJZP/mmexportf1252349630274450efd33eef8297749-1778089401382.gif\n` +
                      `偷看：https://i.postimg.cc/bvLcgz4N/mmexportf4c7a6b8ded22dc3a59a7e77a140ddf4-1778089387939.gif`
                    )}
                    className="tap bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 px-2.5 py-1 rounded text-[10px] border border-amber-500/20 font-bold cursor-pointer"
                  >
                    ⚡ 一键载入所给表情包(46个可爱小猫)
                  </button>
                </div>

                <div className="flex-1 min-h-[180px] mb-4">
                  <textarea
                    value={pastedLinksText}
                    onChange={(e) => setPastedLinksText(e.target.value)}
                    placeholder="粘贴你的链接列表，例如：&#10;表情名1：https://example.com/a.gif&#10;表情名2：https://example.com/b.webp"
                    className="w-full h-full bg-neutral-950/60 border border-neutral-800 rounded-xl p-3 text-[11.5px] font-mono outline-none resize-none focus:border-amber-400"
                  />
                </div>

                <div className="flex gap-3 shrink-0">
                  <button 
                    type="button" 
                    onClick={() => setShowLinkImportModal(false)}
                    className="flex-1 bg-neutral-800 hover:bg-neutral-700 py-2.5 rounded-xl text-xs font-bold text-neutral-300 transition-colors"
                  >
                    取消
                  </button>
                  <button 
                    type="submit" 
                    className="flex-1 bg-amber-500 hover:bg-amber-400 text-neutral-950 py-2.5 rounded-xl text-xs font-bold transition-colors"
                  >
                    确认导入表情 ({pastedLinksText.split('\n').filter(l => l.trim()).length}行)
                  </button>
                </div>
              </form>
            </div>
          )}
        </div>
      )}
    </AppScreen>
  );
}

function Section({
  title,
  icon,
  count,
  onAdd,
  onClear,
  emptyText,
  children,
}: {
  title: string;
  icon: React.ReactNode;
  count: number;
  onAdd: () => void;
  onClear: () => void;
  emptyText: string;
  children: React.ReactNode;
}) {
  return (
    <div className="glass rounded-2xl overflow-hidden text-left">
      <div className="flex items-center justify-between px-4 py-3">
        <div className="flex items-center gap-2 font-medium">
          {icon} {title} <span className="txt-faint text-[12px]">({count})</span>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={onAdd} className="tap w-8 h-8 rounded-full glass flex items-center justify-center txt-accent">
            <Plus size={16} />
          </button>
          {count > 0 && (
            <button onClick={onClear} className="tap text-[12px] txt-faint px-2 py-1">清空</button>
          )}
        </div>
      </div>
      {count === 0 ? (
        <div className="px-4 pb-4 txt-faint text-[13px]">{emptyText}</div>
      ) : (
        children
      )}
    </div>
  );
}
