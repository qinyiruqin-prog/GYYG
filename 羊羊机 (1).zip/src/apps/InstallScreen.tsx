import React, { useState, useEffect } from 'react';
import { Smartphone, Apple, Monitor, Download, Check, HelpCircle, ToggleLeft, ToggleRight, Maximize, Minimize } from 'lucide-react';
import { AppScreen } from '../components/AppScreen';
import type { AppSettings } from '../types';

export function InstallScreen({
  settings,
  updateSettings,
  onBack,
}: {
  settings: AppSettings;
  updateSettings: (patch: Partial<AppSettings>) => void;
  onBack: () => void;
}) {
  const [activeTab, setActiveTab] = useState<'ios' | 'android' | 'pc'>('ios');
  const [canInstall, setCanInstall] = useState(false);
  const [installStatus, setInstallStatus] = useState<'idle' | 'installing' | 'success' | 'failed'>('idle');

  useEffect(() => {
    // Check if stashed install prompt is available
    if ((window as any).deferredPrompt) {
      setCanInstall(true);
    }

    // Listen for the event in case it becomes installable later
    const handleInstallable = () => {
      setCanInstall(true);
    };
    window.addEventListener('pwa-installable', handleInstallable);
    return () => {
      window.removeEventListener('pwa-installable', handleInstallable);
    };
  }, []);

  const handleDirectInstall = async () => {
    const promptEvent = (window as any).deferredPrompt;
    if (!promptEvent) {
      setInstallStatus('failed');
      return;
    }
    try {
      setInstallStatus('installing');
      promptEvent.prompt();
      const { outcome } = await promptEvent.userChoice;
      if (outcome === 'accepted') {
        setInstallStatus('success');
        (window as any).deferredPrompt = null;
        setCanInstall(false);
      } else {
        setInstallStatus('failed');
      }
    } catch (e) {
      console.error('Install failed:', e);
      setInstallStatus('failed');
    }
  };

  const isFs = !!settings.fullscreenMode;

  return (
    <AppScreen title="添加到主屏幕" onBack={onBack}>
      <div className="space-y-5 p-1 pb-10">
        
        {/* Fullscreen Mode Quick Switch */}
        <div className="glass rounded-2xl p-5 border border-indigo-500/20 bg-indigo-950/10">
          <div className="flex items-center justify-between gap-4">
            <div className="flex-1 min-w-0">
              <h3 className="font-title text-base flex items-center gap-2 text-indigo-200">
                {isFs ? <Minimize size={18} className="text-indigo-400" /> : <Maximize size={18} className="text-indigo-400" />}
                自适应宽屏/全屏模式
              </h3>
              <p className="text-[12px] txt-dim mt-1.5 leading-relaxed">
                部分手机型号和浏览器在“免安装快速模式”下无法全屏。开启此项将<strong>解除虚拟手机边框限制</strong>，自适应拉伸并铺满您当前的整个屏幕！
              </p>
            </div>
            <button
              onClick={() => updateSettings({ fullscreenMode: !isFs })}
              className="focus:outline-none cursor-pointer p-1 shrink-0"
            >
              {isFs ? (
                <ToggleRight size={44} className="text-indigo-400" />
              ) : (
                <ToggleLeft size={44} className="text-neutral-500" />
              )}
            </button>
          </div>
          <div className="mt-3 flex items-center gap-2 text-[11px] bg-indigo-500/10 text-indigo-300 px-3 py-1.5 rounded-lg border border-indigo-500/15">
            <HelpCircle size={13} className="shrink-0" />
            <span>不论什么机型，开启此模式后均能享受到完美无缝的全屏。</span>
          </div>
        </div>

        {/* Direct Install Panel */}
        <div className="glass rounded-2xl p-5 space-y-4">
          <h3 className="font-title text-sm txt-accent flex items-center gap-2">
            <Download size={16} />
            一键直接安装
          </h3>
          <p className="text-[12px] txt-dim leading-relaxed">
            如果您的手机或浏览器支持 PWA 标准，您可以点击下方按钮将“羊羊机”直接作为应用快速添加到您的手机桌面，自动隐藏浏览器地址栏，实现 100% 独立全屏。
          </p>

          {canInstall ? (
            <button
              onClick={handleDirectInstall}
              className="w-full py-3.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-500 hover:to-purple-500 text-white rounded-xl text-sm font-semibold flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/10 active:scale-98 transition-all cursor-pointer"
            >
              <Download size={16} />
              立即直接安装到手机/桌面
            </button>
          ) : (
            <div className="space-y-2">
              <button
                onClick={() => setInstallStatus('failed')}
                className="w-full py-3 bg-neutral-800 text-neutral-400 rounded-xl text-sm font-medium flex items-center justify-center gap-2 cursor-not-allowed opacity-60"
                disabled
              >
                一键自动安装不可用
              </button>
              <p className="text-[10px] text-amber-500/80 text-center">
                提示: 您的当前浏览器/设备不支持一键自动唤起，建议您使用下方的<strong>手动添加方法</strong>。
              </p>
            </div>
          )}

          {installStatus === 'success' && (
            <div className="p-3 bg-emerald-500/15 border border-emerald-500/20 text-emerald-400 rounded-xl text-xs flex items-center gap-2">
              <Check size={14} className="shrink-0" />
              <span>安装申请已成功提交！您可以查看手机桌面啦。</span>
            </div>
          )}

          {installStatus === 'failed' && (
            <div className="p-3.5 bg-neutral-900/80 border border-neutral-800 text-neutral-300 rounded-xl space-y-1.5">
              <p className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                💡 手动快捷添加提示：
              </p>
              <p className="text-[11px] text-neutral-400 leading-relaxed">
                大部分移动端（尤其是 iOS Safari 或内置浏览器）在安全环境下只支持<strong>手动添加</strong>。请在下方选择您的手机型号/系统，查看简便的一键手动添加步骤：
              </p>
            </div>
          )}
        </div>

        {/* Tabbed Manual Installation Instructions */}
        <div className="glass rounded-2xl overflow-hidden">
          {/* Tabs header */}
          <div className="flex border-b border-[var(--border)] bg-neutral-900/30">
            <button
              onClick={() => setActiveTab('ios')}
              className={`flex-1 py-3 text-xs font-semibold flex items-center justify-center gap-1.5 border-b-2 transition-colors cursor-pointer ${activeTab === 'ios' ? 'border-[var(--accent)] text-[var(--accent)] bg-neutral-900/10' : 'border-transparent text-neutral-400 hover:text-neutral-200'}`}
            >
              <Apple size={14} />
              苹果 iOS
            </button>
            <button
              onClick={() => setActiveTab('android')}
              className={`flex-1 py-3 text-xs font-semibold flex items-center justify-center gap-1.5 border-b-2 transition-colors cursor-pointer ${activeTab === 'android' ? 'border-[var(--accent)] text-[var(--accent)] bg-neutral-900/10' : 'border-transparent text-neutral-400 hover:text-neutral-200'}`}
            >
              <Smartphone size={14} />
              安卓 Android
            </button>
            <button
              onClick={() => setActiveTab('pc')}
              className={`flex-1 py-3 text-xs font-semibold flex items-center justify-center gap-1.5 border-b-2 transition-colors cursor-pointer ${activeTab === 'pc' ? 'border-[var(--accent)] text-[var(--accent)] bg-neutral-900/10' : 'border-transparent text-neutral-400 hover:text-neutral-200'}`}
            >
              <Monitor size={14} />
              电脑 PC
            </button>
          </div>

          {/* Instructions Body */}
          <div className="p-5">
            {activeTab === 'ios' && (
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-indigo-500/10 text-indigo-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">1</div>
                  <div className="flex-1 text-[12px] text-neutral-300 leading-relaxed">
                    请务必使用 <strong>Safari 浏览器</strong> 打开本网页（微信或其他内置浏览器可能无法添加）。
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-indigo-500/10 text-indigo-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">2</div>
                  <div className="flex-1 text-[12px] text-neutral-300 leading-relaxed flex items-center gap-1 wrap">
                    点击 Safari 浏览器底部的<strong>“分享”按钮</strong>（通常是一个带有向上箭头的正方形：<span className="text-lg leading-none">📤</span>）。
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-indigo-500/10 text-indigo-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">3</div>
                  <div className="flex-1 text-[12px] text-neutral-300 leading-relaxed">
                    在弹出的分享菜单中，向上滑动，找到并点击<strong>“添加到主屏幕”</strong>。
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-indigo-500/10 text-indigo-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">4</div>
                  <div className="flex-1 text-[12px] text-neutral-300 leading-relaxed">
                    点击右上角的<strong>“添加”</strong>。完成后，您的手机桌面上将出现可爱的<strong>“🐑 羊羊机”</strong>图标，点击它就会以完美的<strong>全屏状态</strong>运行了！
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'android' && (
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-purple-500/10 text-purple-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">1</div>
                  <div className="flex-1 text-[12px] text-neutral-300 leading-relaxed">
                    建议使用 <strong>Chrome 浏览器</strong>、<strong>Edge</strong> 或手机自带的<strong>系统默认浏览器</strong>打开本页面。
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-purple-500/10 text-purple-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">2</div>
                  <div className="flex-1 text-[12px] text-neutral-300 leading-relaxed">
                    点击浏览器右上角或底部的<strong>菜单栏</strong>（通常为三个圆点 <span className="font-bold">︙</span> 或三条横线 ☰）。
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-purple-500/10 text-purple-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">3</div>
                  <div className="flex-1 text-[12px] text-neutral-300 leading-relaxed">
                    选择<strong>“添加至主屏幕”</strong>或<strong>“添加快捷方式/安装应用”</strong>（因系统/机型翻译而异）。
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-purple-500/10 text-purple-400 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">4</div>
                  <div className="flex-1 text-[12px] text-neutral-300 leading-relaxed">
                    点击确认。您将会在桌面上看到<strong>“羊羊机”</strong>的应用图标。从桌面点击图标打开即可体验<strong>全屏、无状态栏</strong>的极佳感受。
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'pc' && (
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-stone-500/10 text-stone-300 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">1</div>
                  <div className="flex-1 text-[12px] text-neutral-300 leading-relaxed">
                    推荐使用 <strong>Chrome</strong>、<strong>Edge</strong> 浏览器。
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-stone-500/10 text-stone-300 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">2</div>
                  <div className="flex-1 text-[12px] text-neutral-300 leading-relaxed">
                    观察浏览器地址栏（URL输入框）的右端，会看到一个<strong>“安装应用”图标</strong>（通常是像 <span className="font-bold">📥</span> 带有向下箭头的电脑，或是 <span className="font-bold">⊕</span> 号加号）。
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-stone-500/10 text-stone-300 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">3</div>
                  <div className="flex-1 text-[12px] text-neutral-300 leading-relaxed">
                    点击该图标并确认“安装”。
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-stone-500/10 text-stone-300 flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">4</div>
                  <div className="flex-1 text-[12px] text-neutral-300 leading-relaxed">
                    “羊羊机”将作为一个独立的应用窗口启动，桌面上也会自动生成带有<strong>可爱小羊图标</strong>的快捷方式，后续双击即可直接全屏运行！
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

      </div>
    </AppScreen>
  );
}
