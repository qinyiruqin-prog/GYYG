import { useState, useRef, useEffect } from 'react';
import { Send, Plus, MessageCircle, Trash2, Play, Pause, Eye, Mic, Sparkles, X, UserCheck, UserX, UserPlus, Smile, RefreshCw, Layers, MoreHorizontal, Languages, Settings } from 'lucide-react';
import { AppScreen } from '../components/AppScreen';
import { Modal, Confirm } from '../components/Sheet';
import { ListGroup, Row } from '../components/ui';
import { uid } from '../utils';
import { getPeriodPrompt } from './PeriodScreen';
import { callChatRich, generateImage, textToSpeech, detectNpcs, detectPlotEvents, evaluateOutgoingRequest, generateIncomingRequest, askAI, type ChatMsg } from '../api';
import type { ApiConfig, Character, ChatThread, ChatMessage, WorldEntry, MessageMedia, StoryEvent, UserIdentity, FriendRequest, AppSettings } from '../types';

export function ChatScreen({
  api,
  characters,
  threads,
  worldEntries,
  storyEvents,
  autoNpc,
  users,
  activeUserId,
  friendRequests,
  activeInteractMode,
  activeInteractEnabled,
  updateSettings,
  initialThreadId,
  onClearInitialThreadId,
  onChange,
  onChangeFriendRequests,
  onAddCharacter,
  onAddStoryEvents,
  onConsumeStoryEvents,
  onBack,
  settings,
}: {
  api: ApiConfig;
  characters: Character[];
  threads: ChatThread[];
  worldEntries: WorldEntry[];
  storyEvents: StoryEvent[];
  autoNpc: boolean;
  users: UserIdentity[];
  activeUserId: string | null;
  friendRequests: FriendRequest[];
  activeInteractMode?: 'manual' | 'auto';
  activeInteractEnabled?: boolean;
  updateSettings: (patch: any) => void;
  initialThreadId?: string | null;
  onClearInitialThreadId?: () => void;
  onChange: (threads: ChatThread[]) => void;
  onChangeFriendRequests: (reqs: FriendRequest[]) => void;
  onAddCharacter: (char: Character) => void;
  onAddStoryEvents: (events: StoryEvent[]) => void;
  onConsumeStoryEvents: (ids: string[]) => void;
  onBack: () => void;
  settings: AppSettings;
}) {
  const [activeThreadId, setActiveThreadId] = useState<string | null>(null);

  useEffect(() => {
    if (initialThreadId) {
      setActiveThreadId(initialThreadId);
      if (onClearInitialThreadId) {
        onClearInitialThreadId();
      }
    }
  }, [initialThreadId, onClearInitialThreadId]);

  const [pickingChar, setPickingChar] = useState(false);
  const [confirmDel, setConfirmDel] = useState<ChatThread | null>(null);
  const [confirmDelAll, setConfirmDelAll] = useState(false);
  const [toast, setToast] = useState<string | null>(null);
  const [pendingNpc, setPendingNpcs] = useState<Character[] | null>(null);

  // Tabs for main Chat Screen
  const [activeTab, setActiveTab] = useState<'chats' | 'requests'>('chats');
  
  // Friend requests states
  const [reqTab, setReqTab] = useState<'received' | 'sent'>('received');
  const [composingReq, setComposingReq] = useState(false);
  const [reqSenderId, setReqSenderId] = useState('');
  const [reqCharId, setReqCharId] = useState('');
  const [reqIntro, setReqIntro] = useState('');
  const [submittingReq, setSubmittingReq] = useState(false);
  const [generatingIncoming, setGeneratingIncoming] = useState(false);
  const [revealedChars, setRevealedChars] = useState<Record<string, boolean>>({});

  // Account creation state
  const [isCreatingUser, setIsCreatingUser] = useState(false);
  const [newNick, setNewNick] = useState('');
  const [newSig, setNewSig] = useState('');
  const [newIsAlt, setNewIsAlt] = useState(true);

  // Probing trigger state
  const [triggeringProbe, setTriggeringProbe] = useState(false);
  const [probeCharId, setProbeCharId] = useState('');
  const [probeUserId, setProbeUserId] = useState('');

  const currentUser = users.find((u) => u.id === activeUserId) ?? users[0];

  // Filter threads for active user identity
  const myThreads = threads.filter((t) => !t.userId || t.userId === activeUserId);

  const active = threads.find((t) => t.id === activeThreadId) ?? null;
  const activeChar = characters.find((c) => c.id === active?.characterId) ?? null;

  const updateThread = (id: string, fn: (t: ChatThread) => ChatThread) => {
    onChange(threads.map((t) => (t.id === id ? fn(t) : t)));
  };

  const startChat = (charId: string) => {
    const char = characters.find((c) => c.id === charId);
    if (!char) return;
    const existing = myThreads.find((t) => t.characterId === charId && !t.charAltName);
    if (existing) { setActiveThreadId(existing.id); setPickingChar(false); return; }
    const t: ChatThread = {
      id: uid(),
      characterId: charId,
      userId: activeUserId || undefined,
      messages: [{ id: uid(), role: 'assistant', content: char.greeting || `你好，我是${char.name}。`, ts: Date.now() }],
      updatedAt: Date.now(),
    };
    onChange([t, ...threads]);
    setActiveThreadId(t.id);
    setPickingChar(false);
  };

  const handleQuickCreateUser = () => {
    if (!newNick.trim()) return;
    const newUser: UserIdentity = {
      id: uid(),
      nickname: newNick.trim(),
      signature: newSig.trim(),
      imagePromptTemplate: '',
      isAlt: newIsAlt,
      createdAt: Date.now(),
    };
    updateSettings({
      users: [...users, newUser],
      activeUserId: newUser.id
    });
    setReqSenderId(newUser.id);
    setIsCreatingUser(false);
    setNewNick('');
    setNewSig('');
    setNewIsAlt(true);
    setToast(`成功创建并切换至账号「${newUser.nickname}」！`);
    setTimeout(() => setToast(null), 3000);
  };

  // Trigger Incoming Request from Character
  const triggerCharacterProbing = async (targetCharId?: string, targetUserId?: string) => {
    if (characters.length === 0) {
      setToast('请先在「我的」创建一些 AI 角色！');
      setTimeout(() => setToast(null), 3000);
      return;
    }
    setGeneratingIncoming(true);
    try {
      // Pick selected or random character
      const char = targetCharId 
        ? characters.find((c) => c.id === targetCharId) 
        : characters[Math.floor(Math.random() * characters.length)];
      
      if (!char) throw new Error('未找到所选角色');

      const targetUser = targetUserId 
        ? users.find((u) => u.id === targetUserId)
        : currentUser;

      const res = await generateIncomingRequest(
        api,
        char,
        targetUser?.nickname || '主人',
        targetUser?.signature || ''
      );
      
      const req: FriendRequest = {
        id: uid(),
        type: 'incoming',
        userId: targetUser?.id || activeUserId || currentUser?.id || 'default-owner',
        characterId: char.id,
        charAltName: res.charAltName,
        charAltAvatar: res.charAltAvatar,
        intro: res.intro,
        status: 'pending',
        ts: Date.now()
      };
      
      onChangeFriendRequests([req, ...friendRequests]);
      setToast(`收到来自「${res.charAltName}」对「${targetUser?.nickname}」的好友申请！`);
      setTimeout(() => setToast(null), 3000);
      setTriggeringProbe(false);
    } catch (e) {
      setToast(`生成失败：${(e as Error).message}`);
      setTimeout(() => setToast(null), 3000);
    } finally {
      setGeneratingIncoming(false);
    }
  };

  // Submit User Alt outgoing friend request
  const submitOutgoingRequest = async () => {
    if (!reqCharId || !reqIntro.trim()) return;
    const sender = users.find((u) => u.id === reqSenderId) ?? currentUser;
    const char = characters.find((c) => c.id === reqCharId);
    if (!char || !sender) return;

    setSubmittingReq(true);
    try {
      const res = await evaluateOutgoingRequest(
        api,
        char,
        sender.nickname,
        sender.signature,
        reqIntro.trim()
      );

      const req: FriendRequest = {
        id: uid(),
        type: 'outgoing',
        userId: sender.id,
        characterId: char.id,
        intro: reqIntro.trim(),
        status: res.accepted ? 'accepted' : 'declined',
        reply: res.reply,
        ts: Date.now()
      };

      onChangeFriendRequests([req, ...friendRequests]);

      if (res.accepted) {
        // Automatically create a chat thread for this alt identity and the character
        const existing = threads.find((t) => t.characterId === char.id && t.userId === sender.id && !t.charAltName);
        if (!existing) {
          const newThread: ChatThread = {
            id: uid(),
            characterId: char.id,
            userId: sender.id,
            messages: [
              { id: uid(), role: 'user', content: `[验证消息] ${reqIntro.trim()}`, ts: Date.now() },
              { id: uid(), role: 'assistant', content: res.reply || '好啊，加个好友。', ts: Date.now() }
            ],
            updatedAt: Date.now()
          };
          onChange([newThread, ...threads]);
        }
        setToast(`「${char.name}」已接受你的好友申请！`);
      } else {
        setToast(`「${char.name}」拒绝了你的好友申请`);
      }
      setTimeout(() => setToast(null), 3000);
      setComposingReq(false);
      setReqIntro('');
    } catch (e) {
      setToast(`申请失败：${(e as Error).message}`);
      setTimeout(() => setToast(null), 3000);
    } finally {
      setSubmittingReq(false);
    }
  };

  // Accept incoming friend request
  const acceptIncoming = (r: FriendRequest) => {
    const char = characters.find((c) => c.id === r.characterId);
    if (!char) return;

    // 1. Update request status
    onChangeFriendRequests(friendRequests.map((x) => x.id === r.id ? { ...x, status: 'accepted' as const } : x));

    // 2. Create ChatThread with alt account details
    const existing = threads.find((t) => t.characterId === char.id && t.userId === r.userId && t.charAltName === r.charAltName);
    if (!existing) {
      const newThread: ChatThread = {
        id: uid(),
        characterId: char.id,
        userId: r.userId,
        charAltName: r.charAltName,
        charAltAvatar: r.charAltAvatar,
        messages: [
          { id: uid(), role: 'assistant', content: r.intro, ts: Date.now() }
        ],
        updatedAt: Date.now()
      };
      onChange([newThread, ...threads]);
    }
    setToast('已接受好友申请，可以开始聊天啦');
    setTimeout(() => setToast(null), 3000);
  };

  // Decline incoming friend request
  const declineIncoming = (r: FriendRequest) => {
    onChangeFriendRequests(friendRequests.map((x) => x.id === r.id ? { ...x, status: 'declined' as const } : x));
    setToast('已拒绝好友申请');
    setTimeout(() => setToast(null), 3000);
  };

  const pendingIncomingCount = friendRequests.filter(
    (r) => r.type === 'incoming' && r.status === 'pending' && r.userId === activeUserId
  ).length;

  if (active && activeChar) {
    return (
      <ChatConversation
        api={api}
        char={activeChar}
        thread={active}
        currentUser={currentUser}
        worldEntries={worldEntries}
        characters={characters}
        storyEvents={storyEvents.filter((e) => e.characterId === activeChar.id)}
        autoNpc={autoNpc}
        activeInteractMode={activeInteractMode}
        activeInteractEnabled={activeInteractEnabled}
        onUpdateSettings={updateSettings}
        onSend={(msgs) => updateThread(active.id, (t) => ({ ...t, messages: msgs, updatedAt: Date.now() }))}
        onBack={() => setActiveThreadId(null)}
        onDelete={() => { onChange(threads.filter((t) => t.id !== active.id)); setActiveThreadId(null); }}
        onNpcDetected={(npcs) => setPendingNpcs(npcs)}
        onPlotEvents={(events) => {
          if (events.length) {
            onAddStoryEvents(events);
            setToast(`剧情已同步给 ${events.length} 个角色`);
            setTimeout(() => setToast(null), 3000);
          }
        }}
        onConsumeEvents={(ids) => onConsumeStoryEvents(ids)}
        settings={settings}
      />
    );
  }

  return (
    <AppScreen
      title="聊天"
      onBack={onBack}
      right={
        <div className="flex items-center gap-3.5">
          {myThreads.length > 0 && (
            <button onClick={() => setConfirmDelAll(true)} className="tap text-red-400 hover:text-red-500 text-[12px] font-medium flex items-center gap-0.5 cursor-pointer" title="清空全部对话">
              <Trash2 size={15} /> 清空全部
            </button>
          )}
          <button onClick={() => setPickingChar(true)} className="tap text-[var(--accent)] cursor-pointer" title="开始新会话">
            <Plus size={22} />
          </button>
        </div>
      }
    >
      {/* Top Tab Bar */}
      <div className="flex border-b border-[var(--border)] mb-3 relative shrink-0">
        <button
          onClick={() => setActiveTab('chats')}
          className={`flex-1 py-2.5 text-center text-[14px] font-medium relative transition-colors ${activeTab === 'chats' ? 'txt-accent' : 'txt-faint'}`}
        >
          对话列表 ({myThreads.length})
          {activeTab === 'chats' && <div className="absolute bottom-0 inset-x-8 h-0.5 rounded-full" style={{ background: 'var(--accent)' }} />}
        </button>
        <button
          onClick={() => setActiveTab('requests')}
          className={`flex-1 py-2.5 text-center text-[14px] font-medium relative transition-colors ${activeTab === 'requests' ? 'txt-accent' : 'txt-faint'} flex items-center justify-center gap-1`}
        >
          好友申请
          {pendingIncomingCount > 0 && (
            <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
          )}
          {activeTab === 'requests' && <div className="absolute bottom-0 inset-x-8 h-0.5 rounded-full" style={{ background: 'var(--accent)' }} />}
        </button>
      </div>

      {activeTab === 'chats' ? (
        <>
          <div className="text-[12px] txt-faint mb-3 leading-relaxed">
            与 AI 角色一对一对话。角色会主动发消息、图片、语音，长按消息可查看心声。
            {autoNpc && <span className="txt-accent">对话中提及的新角色会自动生成 NPC。</span>}
          </div>
          {myThreads.length === 0 ? (
            <div className="glass rounded-2xl py-10 text-center txt-faint text-sm">
              当前身份还没有对话，点击右上角 + 选择角色，或去「好友申请」试探！
            </div>
          ) : (
            <ListGroup>
              {[...myThreads].sort((a, b) => b.updatedAt - a.updatedAt).map((t) => {
                const c = characters.find((x) => x.id === t.characterId);
                const last = t.messages[t.messages.length - 1];
                const unreadEvents = storyEvents.filter((e) => e.characterId === t.characterId && !e.consumed).length;
                const labelName = t.charAltName ? `${t.charAltName} (试探小号)` : (c?.name ?? '未知角色');
                const labelAvatar = t.charAltAvatar ? (
                  <div className="w-10 h-10 rounded-full flex items-center justify-center text-xl bg-neutral-800 border border-neutral-700 select-none">
                    {t.charAltAvatar}
                  </div>
                ) : (
                  c?.avatar ? <img src={c.avatar} className="w-10 h-10 rounded-full object-cover" alt="" /> : <div className="w-10 h-10 rounded-full icon-bg flex items-center justify-center"><MessageCircle size={18} className="icon-color" /></div>
                );
                
                return (
                  <Row
                    key={t.id}
                    label={
                      <span className="flex items-center gap-3">
                        {labelAvatar}
                        <span className="truncate max-w-[140px]">{labelName}</span>
                        {unreadEvents > 0 && <span className="text-[10px] px-1.5 py-0.5 rounded-full text-white shrink-0" style={{ background: 'var(--accent)' }}>{unreadEvents}</span>}
                      </span>
                    }
                    hint={last ? `${last.role === 'user' ? '我：' : ''}${last.content.slice(0, 30)}` : ''}
                    onClick={() => setActiveThreadId(t.id)}
                    right={<button onClick={(e) => { e.stopPropagation(); setConfirmDel(t); }} className="tap txt-dim"><Trash2 size={15} /></button>}
                  />
                );
              })}
            </ListGroup>
          )}
        </>
      ) : (
        /* FRIEND REQUESTS TAB */
        <div className="space-y-4">
          {/* Sub tab selectors */}
          <div className="flex gap-2 p-1 glass rounded-xl">
            <button
              onClick={() => setReqTab('received')}
              className={`flex-1 py-1.5 rounded-lg text-[13px] font-medium transition-colors ${reqTab === 'received' ? 'icon-bg-active txt-accent' : 'txt-faint'}`}
            >
              收到的申请 {pendingIncomingCount > 0 && `(${pendingIncomingCount})`}
            </button>
            <button
              onClick={() => setReqTab('sent')}
              className={`flex-1 py-1.5 rounded-lg text-[13px] font-medium transition-colors ${reqTab === 'sent' ? 'icon-bg-active txt-accent' : 'txt-faint'}`}
            >
              我发出的试探
            </button>
          </div>

          {reqTab === 'received' ? (
            /* RECEIVED REQUESTS (Character probing User) */
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] txt-faint pr-2">AI角色会使用伪装身份向你发起好友申请进行试探！</span>
                <button
                  onClick={() => {
                    setProbeCharId(characters[0]?.id || '');
                    setProbeUserId(activeUserId || currentUser?.id || '');
                    setTriggeringProbe(true);
                  }}
                  disabled={generatingIncoming}
                  className="tap flex items-center gap-1 px-3 h-8 rounded-lg text-[11px] txt-accent glass shrink-0"
                >
                  <RefreshCw size={11} className={generatingIncoming ? 'animate-spin' : ''} />
                  {generatingIncoming ? '生成中…' : '🔮 触发试探'}
                </button>
              </div>

              {friendRequests.filter((r) => r.type === 'incoming' && r.userId === activeUserId).length === 0 ? (
                <div className="glass rounded-2xl py-10 text-center txt-faint text-sm">
                  暂时没有收到小号试探。可以点击右上角「触发试探」立刻让AI角色来加你！
                </div>
              ) : (
                <div className="space-y-3">
                  {friendRequests
                    .filter((r) => r.type === 'incoming' && r.userId === activeUserId)
                    .map((r) => {
                      const c = characters.find((char) => char.id === r.characterId);
                      const isRevealed = !!revealedChars[r.id];
                      return (
                        <div key={r.id} className="glass rounded-2xl p-3.5 space-y-3 border border-[var(--border)]">
                          <div className="flex items-center gap-3">
                            <div className="w-11 h-11 rounded-full bg-neutral-800 flex items-center justify-center text-2xl border border-neutral-700 select-none">
                              {r.charAltAvatar || '🕵️'}
                            </div>
                            <div className="flex-1 min-w-0">
                              <div className="text-[14px] font-semibold flex items-center gap-1.5">
                                {r.charAltName}
                                <span className="text-[9px] px-1.5 py-0.5 rounded-full bg-amber-500/15 text-amber-500 shrink-0">匿名试探</span>
                              </div>
                              <div className="text-[10px] txt-faint">申请时间: {new Date(r.ts).toLocaleDateString()}</div>
                            </div>
                          </div>
                          
                          <div className="text-[13px] leading-relaxed p-2.5 rounded-xl bg-neutral-900/50 border border-neutral-800 txt-dim italic">
                            “ {r.intro} ”
                          </div>

                          {/* Show spoiler true character details */}
                          <div className="flex items-center justify-between text-[11px]">
                            <button
                              onClick={() => setRevealedChars((prev) => ({ ...prev, [r.id]: !prev[r.id] }))}
                              className="text-[11px] txt-accent hover:underline flex items-center gap-1"
                            >
                              <Smile size={12} />
                              {isRevealed ? '隐藏真实身份' : '🕵️ 偷看他的真实身份'}
                            </button>
                            {isRevealed && c && (
                              <span className="txt-accent text-[11px] font-medium">
                                真实角色：<strong className="underline">{c.name}</strong>
                              </span>
                            )}
                          </div>

                          {/* Action Buttons */}
                          {r.status === 'pending' ? (
                            <div className="flex gap-2 pt-1">
                              <button
                                onClick={() => declineIncoming(r)}
                                className="tap flex-1 h-9 rounded-xl glass text-[13px] font-medium flex items-center justify-center gap-1 text-red-400"
                              >
                                <UserX size={15} /> 拒绝
                              </button>
                              <button
                                onClick={() => acceptIncoming(r)}
                                className="tap flex-1 h-9 rounded-xl font-medium text-[13px] text-white flex items-center justify-center gap-1"
                                style={{ background: 'var(--accent)', color: 'var(--bg)' }}
                              >
                                <UserCheck size={15} /> 接受
                              </button>
                            </div>
                          ) : (
                            <div className="flex items-center justify-between pt-1 text-[13px]">
                              <span className={`text-[12px] font-medium ${r.status === 'accepted' ? 'text-green-500' : 'text-neutral-500'}`}>
                                {r.status === 'accepted' ? '✓ 已接受好友' : '✕ 已拒绝'}
                              </span>
                              {r.status === 'accepted' && (
                                <button
                                  onClick={() => {
                                    const t = threads.find((th) => th.characterId === r.characterId && th.userId === r.userId && th.charAltName === r.charAltName);
                                    if (t) setActiveThreadId(t.id);
                                  }}
                                  className="px-3 py-1 rounded-lg text-[12px] txt-accent bg-[var(--icon-bg-active)] font-medium"
                                >
                                  进入会话
                                </button>
                              )}
                            </div>
                          )}
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          ) : (
            /* SENT REQUESTS (User alt-account probing Character) */
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <span className="text-[11px] txt-faint pr-2">你可以开着小号对角色进行试探，看看他们是否会通过！</span>
                <button
                  onClick={() => {
                    setReqSenderId(activeUserId || currentUser?.id || '');
                    setReqCharId(characters[0]?.id || '');
                    setComposingReq(true);
                  }}
                  className="tap flex items-center gap-1 px-3 h-8 rounded-lg text-[11px] text-white font-medium shrink-0"
                  style={{ background: 'var(--accent)', color: 'var(--bg)' }}
                >
                  <UserPlus size={11} />
                  发送试探
                </button>
              </div>

              {friendRequests.filter((r) => r.type === 'outgoing' && r.userId === activeUserId).length === 0 ? (
                <div className="glass rounded-2xl py-10 text-center txt-faint text-sm">
                  你还没有向角色发送过小号试探。点「发送试探」开始！
                </div>
              ) : (
                <div className="space-y-3">
                  {friendRequests
                    .filter((r) => r.type === 'outgoing' && r.userId === activeUserId)
                    .map((r) => {
                      const c = characters.find((char) => char.id === r.characterId);
                      const u = users.find((x) => x.id === r.userId);
                      return (
                        <div key={r.id} className="glass rounded-2xl p-3.5 space-y-3 border border-[var(--border)]">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] txt-faint flex items-center gap-1">
                              <Layers size={11} />
                              使用身份：<strong className="txt-dim">{u?.nickname || '我'}</strong>
                            </span>
                            <span className={`text-[10px] font-medium px-2 py-0.5 rounded-full ${r.status === 'accepted' ? 'bg-green-500/10 text-green-500' : 'bg-red-500/10 text-red-500'}`}>
                              {r.status === 'accepted' ? '对方已同意' : '对方已拒绝'}
                            </span>
                          </div>

                          <div className="space-y-1">
                            <div className="text-[13px] font-medium text-neutral-400">
                              向 <strong className="txt-accent font-semibold">{c?.name}</strong> 发送申请：
                            </div>
                            <div className="text-[13px] leading-relaxed p-2.5 rounded-xl bg-neutral-900/50 border border-neutral-800 txt-dim italic">
                              “ {r.intro} ”
                            </div>
                          </div>

                          {r.reply && (
                            <div className="space-y-1 p-2.5 rounded-xl bg-[var(--icon-bg)] border border-[var(--border)]">
                              <div className="text-[11px] font-medium txt-accent">
                                💬 {c?.name} 的回复：
                              </div>
                              <div className="text-[13px] leading-relaxed txt-dim">
                                {r.reply}
                              </div>
                            </div>
                          )}

                          {r.status === 'accepted' && (
                            <div className="flex justify-end pt-1">
                              <button
                                onClick={() => {
                                  const t = threads.find((th) => th.characterId === r.characterId && th.userId === r.userId && !th.charAltName);
                                  if (t) setActiveThreadId(t.id);
                                }}
                                className="px-3 py-1.5 rounded-xl text-[12px] font-medium text-white"
                                style={{ background: 'var(--accent)', color: 'var(--bg)' }}
                              >
                                开始聊天
                              </button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Modal to compose Outgoing Request */}
      <Modal open={composingReq} onClose={() => setComposingReq(false)} title="新建小号试探好友申请">
        <div className="space-y-4">
          <div>
            <label className="text-[12px] txt-faint block mb-1">选择你用于试探的身份</label>
            <div className="space-y-1.5 max-h-[140px] overflow-y-auto no-scrollbar">
              {users.map((u) => (
                <button
                  key={u.id}
                  onClick={() => setReqSenderId(u.id)}
                  className={`w-full flex items-center justify-between p-2 rounded-xl text-left border ${reqSenderId === u.id ? 'border-[var(--accent)] bg-[var(--icon-bg-active)]' : 'border-[var(--border)] glass'}`}
                >
                  <div>
                    <span className="text-[13px] font-medium txt-dim">{u.nickname}</span>
                    {u.isAlt && <span className="ml-1.5 text-[9px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-500 font-semibold">小号</span>}
                  </div>
                  <span className="text-[11px] txt-faint truncate max-w-[120px]">{u.signature}</span>
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[12px] txt-faint block mb-1">选择目标 AI 角色</label>
            <div className="grid grid-cols-2 gap-2 max-h-[120px] overflow-y-auto no-scrollbar">
              {characters.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setReqCharId(c.id)}
                  className={`p-2 rounded-xl text-center border text-[13px] truncate ${reqCharId === c.id ? 'border-[var(--accent)] bg-[var(--icon-bg-active)] txt-accent' : 'border-[var(--border)] glass txt-dim'}`}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[12px] txt-faint block mb-1">输入申请验证消息（试探内容）</label>
            <textarea
              value={reqIntro}
              onChange={(e) => setReqIntro(e.target.value)}
              placeholder="例如：哈喽，今天在自习室看到你，觉得你很有气质，可以通过一下吗？或者问一些敏感的秘密..."
              rows={3}
              maxLength={150}
              className="w-full glass rounded-xl p-2.5 text-[13px] outline-none bg-transparent resize-none border border-[var(--border)] placeholder:text-[var(--text-faint)]"
            />
          </div>

          <button
            onClick={submitOutgoingRequest}
            disabled={submittingReq || !reqCharId || !reqIntro.trim()}
            className="tap w-full h-11 rounded-full font-medium text-[14px] flex items-center justify-center gap-1.5 text-white disabled:opacity-40"
            style={{ background: 'var(--accent)', color: 'var(--bg)' }}
          >
            {submittingReq ? (
              <>
                <span className="animate-spin text-sm">⏳</span> 对方正在考虑中…
              </>
            ) : (
              '发送好友试探申请'
            )}
          </button>
        </div>
      </Modal>

      {/* Modal to compose Outgoing Request */}
      <Modal open={composingReq} onClose={() => { setComposingReq(false); setIsCreatingUser(false); }} title="新建小号试探好友申请">
        <div className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="text-[12px] txt-faint">选择你用于试探的身份</label>
              {!isCreatingUser && (
                <button
                  type="button"
                  onClick={() => setIsCreatingUser(true)}
                  className="text-[11px] txt-accent flex items-center gap-0.5 hover:underline"
                >
                  ➕ 快速创建测试账号
                </button>
              )}
            </div>

            {isCreatingUser ? (
              <div className="p-3.5 rounded-2xl border border-[var(--border)] bg-neutral-900/40 space-y-3 animate-fade-in">
                <div className="text-[11.5px] font-bold txt-accent">新建测试账号/身份</div>
                <input
                  type="text"
                  value={newNick}
                  onChange={(e) => setNewNick(e.target.value)}
                  placeholder="输入账号昵称 (如: 极速测试员 / 侦探小白)"
                  className="w-full glass rounded-xl px-3 py-2 text-[12px] outline-none bg-transparent"
                />
                <input
                  type="text"
                  value={newSig}
                  onChange={(e) => setNewSig(e.target.value)}
                  placeholder="输入个性签名/描述"
                  className="w-full glass rounded-xl px-3 py-2 text-[12px] outline-none bg-transparent"
                />
                <div className="flex items-center justify-between">
                  <label className="flex items-center gap-1.5 cursor-pointer text-[11px] txt-dim select-none">
                    <input
                      type="checkbox"
                      checked={newIsAlt}
                      onChange={(e) => setNewIsAlt(e.target.checked)}
                      className="w-3.5 h-3.5 accent-[var(--accent)]"
                    />
                    设为匿名小号
                  </label>
                  <div className="flex gap-2">
                    <button
                      type="button"
                      onClick={() => setIsCreatingUser(false)}
                      className="px-3 py-1.5 rounded-lg glass text-[11px] txt-dim"
                    >
                      取消
                    </button>
                    <button
                      type="button"
                      onClick={handleQuickCreateUser}
                      disabled={!newNick.trim()}
                      className="px-3 py-1.5 rounded-lg text-[11px] font-medium text-white disabled:opacity-40"
                      style={{ background: 'var(--accent)', color: 'var(--bg)' }}
                    >
                      创建并使用
                    </button>
                  </div>
                </div>
              </div>
            ) : (
              <div className="space-y-1.5 max-h-[140px] overflow-y-auto no-scrollbar">
                {users.map((u) => (
                  <button
                    key={u.id}
                    onClick={() => setReqSenderId(u.id)}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl text-left border ${reqSenderId === u.id ? 'border-[var(--accent)] bg-[var(--icon-bg-active)]' : 'border-[var(--border)] glass'}`}
                  >
                    <div>
                      <span className="text-[13px] font-medium txt-dim">{u.nickname}</span>
                      {u.isAlt && <span className="ml-1.5 text-[9px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-500 font-semibold">小号</span>}
                    </div>
                    <span className="text-[11px] txt-faint truncate max-w-[120px]">{u.signature}</span>
                  </button>
                ))}
              </div>
            )}
          </div>

          <div>
            <label className="text-[12px] txt-faint block mb-1">选择目标 AI 角色</label>
            <div className="grid grid-cols-2 gap-2 max-h-[120px] overflow-y-auto no-scrollbar">
              {characters.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setReqCharId(c.id)}
                  className={`p-2 rounded-xl text-center border text-[13px] truncate ${reqCharId === c.id ? 'border-[var(--accent)] bg-[var(--icon-bg-active)] txt-accent' : 'border-[var(--border)] glass txt-dim'}`}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[12px] txt-faint block mb-1">输入申请验证消息（试探内容）</label>
            <textarea
              value={reqIntro}
              onChange={(e) => setReqIntro(e.target.value)}
              placeholder="例如：哈喽，今天在自习室看到你，觉得你很有气质，可以通过一下吗？或者问一些敏感的秘密..."
              rows={3}
              maxLength={150}
              className="w-full glass rounded-xl p-2.5 text-[13px] outline-none bg-transparent resize-none border border-[var(--border)] placeholder:text-[var(--text-faint)]"
            />
          </div>

          <button
            onClick={submitOutgoingRequest}
            disabled={submittingReq || !reqCharId || !reqIntro.trim()}
            className="tap w-full h-11 rounded-full font-medium text-[14px] flex items-center justify-center gap-1.5 text-white disabled:opacity-40"
            style={{ background: 'var(--accent)', color: 'var(--bg)' }}
          >
            {submittingReq ? (
              <>
                <span className="animate-spin text-sm">⏳</span> 对方正在考虑中…
              </>
            ) : (
              '发送好友试探申请'
            )}
          </button>
        </div>
      </Modal>

      {/* Modal to configure and Trigger Incoming Request (AI probing User) */}
      <Modal open={triggeringProbe} onClose={() => setTriggeringProbe(false)} title="触发 AI 角色小号试探">
        <div className="space-y-4">
          <div className="text-[12.5px] txt-dim leading-relaxed">
            AI 角色也会创建“匿名小号”来主动添加你的账号，试图隐藏真实身份对你发起剧情试探或调戏！在下方选择发起与接收方：
          </div>

          <div>
            <label className="text-[12px] txt-faint block mb-1.5 font-medium">发起试探的 AI 角色</label>
            <div className="grid grid-cols-2 gap-2 max-h-[140px] overflow-y-auto no-scrollbar">
              <button
                onClick={() => setProbeCharId('')}
                className={`p-2 rounded-xl text-center border text-[13px] truncate ${probeCharId === '' ? 'border-[var(--accent)] bg-[var(--icon-bg-active)] txt-accent font-semibold' : 'border-[var(--border)] glass txt-dim'}`}
              >
                🎲 随机角色
              </button>
              {characters.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setProbeCharId(c.id)}
                  className={`p-2 rounded-xl text-center border text-[13px] truncate ${probeCharId === c.id ? 'border-[var(--accent)] bg-[var(--icon-bg-active)] txt-accent font-semibold' : 'border-[var(--border)] glass txt-dim'}`}
                >
                  {c.name}
                </button>
              ))}
            </div>
          </div>

          <div>
            <label className="text-[12px] txt-faint block mb-1.5 font-medium">接收申请的用户账号 (Identity)</label>
            <div className="space-y-1.5 max-h-[140px] overflow-y-auto no-scrollbar">
              {users.map((u) => (
                <button
                  key={u.id}
                  onClick={() => setProbeUserId(u.id)}
                  className={`w-full flex items-center justify-between p-2 rounded-xl text-left border ${probeUserId === u.id ? 'border-[var(--accent)] bg-[var(--icon-bg-active)] font-semibold' : 'border-[var(--border)] glass'}`}
                >
                  <div>
                    <span className="text-[13px] txt-dim">{u.nickname}</span>
                    {u.isAlt && <span className="ml-1.5 text-[9px] px-1.5 py-0.5 rounded bg-amber-500/10 text-amber-500 font-semibold">小号</span>}
                    {activeUserId === u.id && <span className="ml-1.5 text-[9px] px-1.5 py-0.5 rounded bg-[var(--accent-2)] text-white">当前</span>}
                  </div>
                  <span className="text-[11px] txt-faint truncate max-w-[120px]">{u.signature}</span>
                </button>
              ))}
            </div>
          </div>

          <div className="flex gap-3 pt-2">
            <button
              onClick={() => setTriggeringProbe(false)}
              className="tap flex-1 h-11 rounded-full glass text-[13px] font-medium"
            >
              取消
            </button>
            <button
              onClick={() => triggerCharacterProbing(probeCharId || undefined, probeUserId || undefined)}
              disabled={generatingIncoming}
              className="tap flex-1 h-11 rounded-full font-medium text-[13px] text-white flex items-center justify-center gap-1.5"
              style={{ background: 'var(--accent)', color: 'var(--bg)' }}
            >
              {generatingIncoming ? (
                <>
                  <span className="animate-spin text-sm">⏳</span> 智能生成中…
                </>
              ) : (
                '🔮 触发试探'
              )}
            </button>
          </div>
        </div>
      </Modal>
      <Modal open={pickingChar} onClose={() => setPickingChar(false)} title="选择角色开始聊天">
        {characters.length === 0 ? (
          <div className="text-center txt-faint py-6">还没有角色。去「我的」创建吧。</div>
        ) : (
          <div className="space-y-2 max-h-[50vh] overflow-y-auto no-scrollbar">
            {characters.map((c) => (
              <button key={c.id} onClick={() => startChat(c.id)} className="tap w-full flex items-center gap-3 p-2.5 rounded-xl glass">
                {c.avatar ? <img src={c.avatar} className="w-10 h-10 rounded-full object-cover" alt="" /> : <div className="w-10 h-10 rounded-full icon-bg flex items-center justify-center"><MessageCircle size={18} className="icon-color" /></div>}
                <div className="flex-1 text-left min-w-0">
                  <div className="text-[15px]">{c.name}</div>
                  <div className="text-[12px] txt-faint truncate">{c.signature}</div>
                </div>
              </button>
            ))}
          </div>
        )}
      </Modal>

      <Confirm open={!!confirmDel} title="删除对话" message="确定删除这段对话？所有消息将清除。" danger onConfirm={() => { if (confirmDel) onChange(threads.filter((t) => t.id !== confirmDel.id)); setConfirmDel(null); }} onCancel={() => setConfirmDel(null)} />

      <Confirm open={confirmDelAll} title="清空全部对话" message="确定要清空您当前的所有对话吗？此操作将永久清除全部聊天记录且不可撤销。" danger onConfirm={() => { onChange(threads.filter((t) => t.userId !== activeUserId)); setConfirmDelAll(false); }} onCancel={() => setConfirmDelAll(false)} />

      {toast && (
        <div className="absolute bottom-20 inset-x-0 flex justify-center z-50 pointer-events-none">
          <div className="glass-strong rounded-full px-4 py-2 text-[13px] animate-fade-in flex items-center gap-2">
            <Sparkles size={14} className="txt-accent" /> {toast}
          </div>
        </div>
      )}
    </AppScreen>
  );
}

function ChatConversation({
  api, char, thread, currentUser, worldEntries, characters, storyEvents, autoNpc,
  activeInteractMode, activeInteractEnabled, onUpdateSettings,
  onSend, onBack, onDelete, onNpcDetected, onPlotEvents, onConsumeEvents,
  settings,
}: {
  api: ApiConfig;
  char: Character;
  thread: ChatThread;
  currentUser: UserIdentity | undefined;
  worldEntries: WorldEntry[];
  characters: Character[];
  storyEvents: StoryEvent[];
  autoNpc: boolean;
  activeInteractMode?: 'manual' | 'auto';
  activeInteractEnabled?: boolean;
  onUpdateSettings?: (patch: any) => void;
  onSend: (msgs: ChatMessage[]) => void;
  onBack: () => void;
  onDelete: () => void;
  onNpcDetected: (npcs: Character[]) => void;
  onPlotEvents: (events: StoryEvent[]) => void;
  onConsumeEvents: (ids: string[]) => void;
  settings: AppSettings;
}) {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [thinkingMsg, setThinkingMsg] = useState<string | null>(null);
  
  // Gear shift console states
  const [showGearShift, setShowGearShift] = useState(false);
  const [shifterLocked, setShifterLocked] = useState(true);
  const [lockWarning, setLockWarning] = useState(false);

  const endRef = useRef<HTMLDivElement>(null);
  const longPressTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const [translations, setTranslations] = useState<Record<string, string>>({});
  const [showTranslation, setShowTranslation] = useState<Record<string, boolean>>({});
  const [translatingId, setTranslatingId] = useState<string | null>(null);

  // Character specific settings states
  const [showConfigModal, setShowConfigModal] = useState(false);
  const [minWords, setMinWords] = useState<string>(char.replyMinWords?.toString() ?? '');
  const [maxWords, setMaxWords] = useState<string>(char.replyMaxWords?.toString() ?? '');
  const [minCount, setMinCount] = useState<string>(char.replyMinCount?.toString() ?? '');
  const [maxCount, setMaxCount] = useState<string>(char.replyMaxCount?.toString() ?? '');
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  // Expression packs states
  const [showStickers, setShowStickers] = useState(false);
  const [selectedPackTabId, setSelectedPackTabId] = useState<string | null>(null);

  const connectedPacks = (settings.expressionPacks || []).filter(p => p.characterConnections?.includes(char.id));

  useEffect(() => {
    setMinWords(char.replyMinWords?.toString() ?? '');
    setMaxWords(char.replyMaxWords?.toString() ?? '');
    setMinCount(char.replyMinCount?.toString() ?? '');
    setMaxCount(char.replyMaxCount?.toString() ?? '');
  }, [char.id, char.replyMinWords, char.replyMaxWords, char.replyMinCount, char.replyMaxCount]);

  const handleSaveConfig = () => {
    const minW = minWords.trim() === '' ? undefined : parseInt(minWords.trim(), 10);
    const maxW = maxWords.trim() === '' ? undefined : parseInt(maxWords.trim(), 10);
    const minC = minCount.trim() === '' ? undefined : parseInt(minCount.trim(), 10);
    const maxC = maxCount.trim() === '' ? undefined : parseInt(maxCount.trim(), 10);

    if (onUpdateSettings) {
      onUpdateSettings({
        characters: settings.characters.map((c) =>
          c.id === char.id
            ? {
                ...c,
                replyMinWords: minW,
                replyMaxWords: maxW,
                replyMinCount: minC,
                replyMaxCount: maxC,
              }
            : c
        ),
      });
    }
    setShowConfigModal(false);
  };

  const handleDeleteAllData = () => {
    if (onUpdateSettings) {
      const nextCharacters = settings.characters.filter((c) => c.id !== char.id);
      const nextThreads = settings.chatThreads.filter((t) => t.characterId !== char.id);
      const nextContacts = settings.contacts.filter((c) => c.characterId !== char.id);

      onUpdateSettings({
        characters: nextCharacters,
        chatThreads: nextThreads,
        contacts: nextContacts,
      });
      setShowDeleteConfirm(false);
      setShowConfigModal(false);
      onBack();
    }
  };

  const toggleTranslate = async (m: ChatMessage) => {
    if (showTranslation[m.id]) {
      setShowTranslation((prev) => ({ ...prev, [m.id]: false }));
      return;
    }
    if (translations[m.id]) {
      setShowTranslation((prev) => ({ ...prev, [m.id]: true }));
      return;
    }

    setTranslatingId(m.id);
    try {
      const prompt = "你是一个专业的高保真中英互译翻译官。请将用户的输入文本进行精准、自然的双语互译。如果是中文文本，请翻译成纯英文；如果是英文、拼音、外文或其他混合文本，请翻译成纯中文。请不要带任何多余的解释、回复或格式（如「好的，这是翻译：」），直接输出翻译后的目标纯文本。";
      const result = await askAI(api, prompt, m.content);
      setTranslations((prev) => ({ ...prev, [m.id]: result }));
      setShowTranslation((prev) => ({ ...prev, [m.id]: true }));
    } catch (err: any) {
      console.error('Translation error:', err);
      alert('翻译失败：' + (err.message || String(err)));
    } finally {
      setTranslatingId(null);
    }
  };

  const [activeMessageMenu, setActiveMessageMenu] = useState<ChatMessage | null>(null);

  const reroll = async () => {
    if (loading) return;
    
    const lastUserIdx = [...thread.messages].reverse().findIndex(m => m.role === 'user');
    let next: ChatMessage[] = [];
    if (lastUserIdx !== -1) {
      const actualIdx = thread.messages.length - 1 - lastUserIdx;
      next = thread.messages.slice(0, actualIdx + 1);
    } else {
      const lastAssistantIdx = [...thread.messages].reverse().findIndex(m => m.role === 'assistant');
      if (lastAssistantIdx === -1) return;
      const actualIdx = thread.messages.length - 1 - lastAssistantIdx;
      next = thread.messages.slice(0, actualIdx);
    }
    
    onSend(next);
    setLoading(true);
    setThinkingMsg('对方正在输入…');
    try {
      const minReplies = char.replyMinCount ?? 1;
      const maxReplies = char.replyMaxCount ?? 1;
      const clampedMin = Math.max(1, minReplies);
      const clampedMax = Math.max(clampedMin, maxReplies);
      const totalReplies = clampedMin + Math.floor(Math.random() * (clampedMax - clampedMin + 1));

      let currentMsgs = [...next];

      for (let i = 0; i < totalReplies; i++) {
        if (i > 0) {
          setThinkingMsg('对方正在输入…');
          await new Promise((resolve) => setTimeout(resolve, 800));
        }

        const sysInstruction = totalReplies > 1
          ? `\n\n[多条回复机制]
你在这轮对话中正在进行多条连发回复。总条数为 ${totalReplies} 条。
当前正在发送第 ${i + 1} 条。
${i + 1 < totalReplies 
  ? '这是连发回复的中间条目，请只说其中一部分内容，绝对不要把所有话一次性说完！保持口语化，像在发微信一样，短小精悍，剩下的在下一条消息中继续发。不要重复已发送的内容。' 
  : '这是连发回复的最后一条，请结束你本次的全部表达并收尾。'}`
          : '';

        const history: ChatMsg[] = [
          { role: 'system', content: buildSystem() + sysInstruction },
          ...currentMsgs.map((m) => ({ role: m.role, content: m.content } as ChatMsg)),
        ];

        const rich = await callChatRich(api.chat, history, { temperature: 0.85, maxTokens: 800 });
        const assistantMsg: ChatMessage = {
          id: uid(),
          role: 'assistant',
          content: rich.content,
          innerThought: rich.innerThought,
          ts: Date.now(),
        };

        currentMsgs = [...currentMsgs, assistantMsg];
        onSend(currentMsgs);

        // Media generation
        const media: MessageMedia[] = [];
        try {
          if (rich.sendImage && rich.imagePrompt) {
            const appearance = char.imagePromptTemplate ? `${char.imagePromptTemplate}, ` : '';
            const imgUrl = await generateImage(api.image, appearance + rich.imagePrompt, { faceRef: char.faceRef });
            media.push({ kind: 'image', url: imgUrl });
          }
        } catch { /* image optional */ }
        try {
          if (rich.sendVoice && rich.voiceText) {
            const { url, duration } = await textToSpeech(api.voice, rich.voiceText);
            media.push({ kind: 'voice', url, duration, text: rich.voiceText });
          }
        } catch { /* voice optional */ }
        if (media.length) {
          const mediaMsg: ChatMessage = { id: uid(), role: 'assistant', content: '', ts: Date.now(), media };
          currentMsgs = [...currentMsgs, mediaMsg];
          onSend(currentMsgs);
        }
      }
    } catch (e) {
      onSend([...next, { id: uid(), role: 'assistant', content: `（重试出错了：${(e as Error).message}）`, ts: Date.now() }]);
    } finally {
      setLoading(false);
      setThinkingMsg(null);
    }
  };

  const isForeignLanguage = (text: string): boolean => {
    if (!text) return false;
    const cyrillicCharCount = (text.match(/[\u0400-\u04FF]/g) || []).length;
    const latinCharCount = (text.match(/[a-zA-Z\u00C0-\u00FF]/g) || []).length;
    const chineseCharCount = (text.match(/[\u4e00-\u9fa5]/g) || []).length;

    if (cyrillicCharCount > 0) return true;
    if (latinCharCount > 5 && chineseCharCount < latinCharCount) return true;
    return false;
  };

  useEffect(() => {
    if (!settings.autoTranslate) return;
    const lastMsg = thread.messages[thread.messages.length - 1];
    if (lastMsg && lastMsg.role === 'assistant' && lastMsg.content && !translations[lastMsg.id] && translatingId !== lastMsg.id) {
      if (isForeignLanguage(lastMsg.content)) {
        const performAutoTranslate = async () => {
          setTranslatingId(lastMsg.id);
          try {
            const prompt = "你是一个专业的高保真多国语言翻译官。请将用户输入的俄文、英文、法文等外语文本，精准、自然地翻译成简体中文。请不要带任何多余的解释、回复或格式，直接输出翻译后的目标简体中文纯文本。";
            const result = await askAI(api, prompt, lastMsg.content);
            setTranslations((prev) => ({ ...prev, [lastMsg.id]: result }));
            setShowTranslation((prev) => ({ ...prev, [lastMsg.id]: true }));
          } catch (err: any) {
            console.error('Auto translation error:', err);
          } finally {
            setTranslatingId(null);
          }
        };
        performAutoTranslate();
      }
    }
  }, [thread.messages, settings.autoTranslate, translations, translatingId, api]);

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [thread.messages, loading]);

  useEffect(() => {
    const unconsumed = storyEvents.filter((e) => !e.consumed);
    if (unconsumed.length) onConsumeEvents(unconsumed.map((e) => e.id));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [char.id]);

  const buildSystem = (): string => {
    let sys = char.persona || `你是${char.name}。保持角色设定，自然地回应。`;
    if (thread.charAltName) {
      sys += `\n\n[特殊设定]
你现在正在使用你为试探用户特意开启的匿名/试探小号「${thread.charAltName}」来和用户「${currentUser?.nickname || '我'}」聊天！
你的真实身份是「${char.name}」，而用户不知道你这个账号是「${char.name}」开启的。
请深度扮演这个小号设定的个性和特征与用户对话，千万不能穿帮暴露出你真实的${char.name}身份！
但是在你的内心活动（innerThought）中，你必须体现出你作为「${char.name}」在背后使用这个小号观察、试探、调戏用户的真正心理、好笑和得意的态度！`;
    } else {
      sys += `\n\n[对话人物设定]
你正在和「${currentUser?.nickname || '我'}」聊天。对方的签名是：「${currentUser?.signature || ''}」${currentUser?.isAlt ? '，此账号是用户的匿名/试探小号。' : '，此账号是用户的主账号。'}`;
    }

    // Insert word limits
    let limitsPrompt = '';
    if (char.replyMinWords !== undefined && char.replyMinWords > 0) {
      limitsPrompt += `不少于 ${char.replyMinWords} 字`;
    }
    if (char.replyMaxWords !== undefined && char.replyMaxWords > 0) {
      if (limitsPrompt) limitsPrompt += '，且';
      limitsPrompt += `不多于 ${char.replyMaxWords} 字`;
    }
    if (limitsPrompt) {
      sys += `\n\n[字数限制要求]
你的本次回复正文（即返回 JSON 中的 "content" 字段，不含 innerThought 思想等其他辅助字段，仅算回复给用户的纯文本）在长度（含标点符号）上必须满足：${limitsPrompt}。请严格遵守该字数限制，根据限制控制叙述的详略程度。`;
    }

    const recent = thread.messages.slice(-6).map((m) => m.content).join(' ');
    const matched = worldEntries.filter((w) => w.key && recent.includes(w.key));
    if (matched.length) {
      sys += '\n\n[世界观参考]\n' + matched.sort((a, b) => b.priority - a.priority).map((w) => `${w.key}：${w.content}`).join('\n');
    }
    const unconsumed = storyEvents.filter((e) => !e.consumed);
    if (unconsumed.length) {
      sys += '\n\n[你应该知道的事]\n' + unconsumed.map((e) => `${e.sourceCharName}那里发生的事：${e.summary}`).join('\n');
    }
    sys += getPeriodPrompt(settings);
    return sys;
  };

  const sendSticker = async (stickerUrl: string) => {
    if (loading) return;
    setShowStickers(false);
    const userMsg: ChatMessage = { 
      id: uid(), 
      role: 'user', 
      content: '', 
      media: [{ kind: 'image', url: stickerUrl, isSticker: true }],
      ts: Date.now() 
    };
    const next = [...thread.messages, userMsg];
    onSend(next);
    setLoading(true);
    setThinkingMsg('对方正在输入…');
    try {
      const minReplies = char.replyMinCount ?? 1;
      const maxReplies = char.replyMaxCount ?? 1;
      const clampedMin = Math.max(1, minReplies);
      const clampedMax = Math.max(clampedMin, maxReplies);
      const totalReplies = clampedMin + Math.floor(Math.random() * (clampedMax - clampedMin + 1));

      let currentMsgs = [...next];

      for (let i = 0; i < totalReplies; i++) {
        if (i > 0) {
          setThinkingMsg('对方正在输入…');
          await new Promise((resolve) => setTimeout(resolve, 800));
        }

        const sysInstruction = totalReplies > 1
          ? `\n\n[多条回复机制]
你在这轮对话中正在进行多条连发回复。总条数为 ${totalReplies} 条。
当前正在发送第 ${i + 1} 条。
${i + 1 < totalReplies 
  ? '这是连发回复的中间条目，请只说其中一部分内容，绝对不要把所有话一次性说完！保持口语化，像在发微信一样，短小精悍，剩下的在下一条消息中继续发。不要重复已发送的内容。' 
  : '这是连发回复的最后一条，请结束你本次的全部表达并收尾。'}`
          : '';

        const stickerInstruction = `\n\n[系统提示：用户给你发送了一张表情包图片（Sticker）。请结合语境，进行俏皮、人性化的反馈回复。]`;

        const history: ChatMsg[] = [
          { role: 'system', content: buildSystem() + stickerInstruction + sysInstruction },
          ...currentMsgs.map((m) => ({ role: m.role, content: m.content || '（发送了一张表情包）' } as ChatMsg)),
        ];

        const rich = await callChatRich(api.chat, history, { temperature: 0.85, maxTokens: 800 });
        const assistantMsg: ChatMessage = {
          id: uid(),
          role: 'assistant',
          content: rich.content,
          innerThought: rich.innerThought,
          ts: Date.now(),
        };

        currentMsgs = [...currentMsgs, assistantMsg];
        onSend(currentMsgs);

        // Media generation (chance to send expression sticker back)
        const media: MessageMedia[] = [];

        // 30% chance to send back a matching sticker if connected packs exist
        const probability = Math.random() < 0.30;
        if (probability && connectedPacks.length > 0) {
          const allStickers = connectedPacks.flatMap(p => p.expressions);
          if (allStickers.length > 0) {
            let matched = allStickers.find(s => rich.content.includes(s.name));
            if (!matched) {
              const happyWords = ['哈', '笑', '开心', '耶', '太好', '喜', '得意', 'happy', 'laugh'];
              const sadWords = ['哭', '难过', '委屈', '伤心', '呜', '哀', 'sad', 'cry'];
              const angryWords = ['气', '哼', '怒', '讨厌', '怪', 'angry'];
              const shyWords = ['羞', '脸红', '捂脸', '笨', '羞涩', 'shy'];

              const hasHappy = happyWords.some(w => rich.content.includes(w));
              const hasSad = sadWords.some(w => rich.content.includes(w));
              const hasAngry = angryWords.some(w => rich.content.includes(w));
              const hasShy = shyWords.some(w => rich.content.includes(w));

              if (hasHappy) matched = allStickers.find(s => s.name.includes('笑') || s.name.includes('开心') || s.name.includes('得意') || s.name.includes('乐'));
              if (!matched && hasSad) matched = allStickers.find(s => s.name.includes('哭') || s.name.includes('难过') || s.name.includes('委屈') || s.name.includes('泪'));
              if (!matched && hasAngry) matched = allStickers.find(s => s.name.includes('生气的') || s.name.includes('哼') || s.name.includes('怒') || s.name.includes('气'));
              if (!matched && hasShy) matched = allStickers.find(s => s.name.includes('害羞') || s.name.includes('羞') || s.name.includes('脸红'));
            }
            const chosenSticker = matched || allStickers[Math.floor(Math.random() * allStickers.length)];
            media.push({ kind: 'image', url: chosenSticker.url, isSticker: true });
          }
        }

        try {
          if (rich.sendImage && rich.imagePrompt) {
            const appearance = char.imagePromptTemplate ? `${char.imagePromptTemplate}, ` : '';
            const imgUrl = await generateImage(api.image, appearance + rich.imagePrompt, { faceRef: char.faceRef });
            media.push({ kind: 'image', url: imgUrl });
          }
        } catch { /* image optional */ }
        try {
          if (rich.sendVoice && rich.voiceText) {
            const { url, duration } = await textToSpeech(api.voice, rich.voiceText);
            media.push({ kind: 'voice', url, duration, text: rich.voiceText });
          }
        } catch { /* voice optional */ }
        if (media.length) {
          const mediaMsg: ChatMessage = { id: uid(), role: 'assistant', content: '', ts: Date.now(), media };
          currentMsgs = [...currentMsgs, mediaMsg];
          onSend(currentMsgs);
        }
      }

      // Background NPC & Plot Event detection (using final state)
      const recentText = currentMsgs.slice(-8).map((m) => `${m.role === 'user' ? '用户' : (thread.charAltName || char.name)}：${m.content}`).join('\n');
      const existingNames = characters.map((c) => c.name);

      if (autoNpc) {
        detectNpcs(api, char.name, recentText, existingNames).then((suggestions) => {
          if (suggestions.length) {
            const newChars: Character[] = suggestions.map((s) => ({
              id: uid(),
              name: s.name,
              avatar: '',
              persona: s.persona,
              greeting: s.greeting,
              signature: s.signature,
              imagePromptTemplate: '',
              createdAt: Date.now(),
            }));
            onNpcDetected(newChars);
          }
        }).catch(() => {});
      }

      const otherNames = existingNames.filter((n) => n !== char.name);
      if (otherNames.length) {
        detectPlotEvents(api, char.name, recentText, otherNames).then((events) => {
          if (events.length) {
            const storyEvts: StoryEvent[] = events.map((e) => {
              const target = characters.find((c) => c.name === e.targetName);
              return {
                id: uid(),
                characterId: target?.id ?? '',
                sourceThreadId: thread.id,
                sourceCharName: char.name,
                summary: e.summary,
                ts: Date.now(),
              };
            });
            onPlotEvents(storyEvts);
          }
        }).catch(() => {});
      }
    } catch (e) {
      onSend([...next, { id: uid(), role: 'assistant', content: `（重试出错了：${(e as Error).message}）`, ts: Date.now() }]);
    } finally {
      setLoading(false);
      setThinkingMsg(null);
    }
  };

  const send = async () => {
    const text = input.trim();
    if (!text || loading) return;
    setInput('');
    const userMsg: ChatMessage = { id: uid(), role: 'user', content: text, ts: Date.now() };
    const next = [...thread.messages, userMsg];
    onSend(next);
    setLoading(true);
    setThinkingMsg('对方正在输入…');
    try {
      const minReplies = char.replyMinCount ?? 1;
      const maxReplies = char.replyMaxCount ?? 1;
      const clampedMin = Math.max(1, minReplies);
      const clampedMax = Math.max(clampedMin, maxReplies);
      const totalReplies = clampedMin + Math.floor(Math.random() * (clampedMax - clampedMin + 1));

      let currentMsgs = [...next];

      for (let i = 0; i < totalReplies; i++) {
        if (i > 0) {
          setThinkingMsg('对方正在输入…');
          await new Promise((resolve) => setTimeout(resolve, 800));
        }

        const sysInstruction = totalReplies > 1
          ? `\n\n[多条回复机制]
你在这轮对话中正在进行多条连发回复。总条数为 ${totalReplies} 条。
当前正在发送第 ${i + 1} 条。
${i + 1 < totalReplies 
  ? '这是连发回复的中间条目，请只说其中一部分内容，绝对不要把所有话一次性说完！保持口语化，像在发微信一样，短小精悍，剩下的在下一条消息中继续发。不要重复已发送的内容。' 
  : '这是连发回复的最后一条，请结束你本次的全部表达并收尾。'}`
          : '';

        const history: ChatMsg[] = [
          { role: 'system', content: buildSystem() + sysInstruction },
          ...currentMsgs.map((m) => ({ role: m.role, content: m.content || '（发送了一张表情包）' } as ChatMsg)),
        ];

        const rich = await callChatRich(api.chat, history, { temperature: 0.85, maxTokens: 800 });
        const assistantMsg: ChatMessage = {
          id: uid(),
          role: 'assistant',
          content: rich.content,
          innerThought: rich.innerThought,
          ts: Date.now(),
        };

        currentMsgs = [...currentMsgs, assistantMsg];
        onSend(currentMsgs);

        // Media generation (chance to send expression sticker back)
        const media: MessageMedia[] = [];

        // 30% chance to send back a matching sticker if connected packs exist
        const probability = Math.random() < 0.30;
        if (probability && connectedPacks.length > 0) {
          const allStickers = connectedPacks.flatMap(p => p.expressions);
          if (allStickers.length > 0) {
            let matched = allStickers.find(s => rich.content.includes(s.name));
            if (!matched) {
              const happyWords = ['哈', '笑', '开心', '耶', '太好', '喜', '得意', 'happy', 'laugh'];
              const sadWords = ['哭', '难过', '委屈', '伤心', '呜', '哀', 'sad', 'cry'];
              const angryWords = ['气', '哼', '怒', '讨厌', '怪', 'angry'];
              const shyWords = ['羞', '脸红', '捂脸', '笨', '羞涩', 'shy'];

              const hasHappy = happyWords.some(w => rich.content.includes(w));
              const hasSad = sadWords.some(w => rich.content.includes(w));
              const hasAngry = angryWords.some(w => rich.content.includes(w));
              const hasShy = shyWords.some(w => rich.content.includes(w));

              if (hasHappy) matched = allStickers.find(s => s.name.includes('笑') || s.name.includes('开心') || s.name.includes('得意') || s.name.includes('乐'));
              if (!matched && hasSad) matched = allStickers.find(s => s.name.includes('哭') || s.name.includes('难过') || s.name.includes('委屈') || s.name.includes('泪'));
              if (!matched && hasAngry) matched = allStickers.find(s => s.name.includes('生气的') || s.name.includes('哼') || s.name.includes('怒') || s.name.includes('气'));
              if (!matched && hasShy) matched = allStickers.find(s => s.name.includes('害羞') || s.name.includes('羞') || s.name.includes('脸红'));
            }
            const chosenSticker = matched || allStickers[Math.floor(Math.random() * allStickers.length)];
            media.push({ kind: 'image', url: chosenSticker.url, isSticker: true });
          }
        }

        try {
          if (rich.sendImage && rich.imagePrompt) {
            const appearance = char.imagePromptTemplate ? `${char.imagePromptTemplate}, ` : '';
            const imgUrl = await generateImage(api.image, appearance + rich.imagePrompt, { faceRef: char.faceRef });
            media.push({ kind: 'image', url: imgUrl });
          }
        } catch { /* image optional */ }
        try {
          if (rich.sendVoice && rich.voiceText) {
            const { url, duration } = await textToSpeech(api.voice, rich.voiceText);
            media.push({ kind: 'voice', url, duration, text: rich.voiceText });
          }
        } catch { /* voice optional */ }
        if (media.length) {
          const mediaMsg: ChatMessage = { id: uid(), role: 'assistant', content: '', ts: Date.now(), media };
          currentMsgs = [...currentMsgs, mediaMsg];
          onSend(currentMsgs);
        }
      }

      // Background NPC & Plot Event detection (using final state)
      const recentText = currentMsgs.slice(-8).map((m) => `${m.role === 'user' ? '用户' : (thread.charAltName || char.name)}：${m.content}`).join('\n');
      const existingNames = characters.map((c) => c.name);

      if (autoNpc) {
        detectNpcs(api, char.name, recentText, existingNames).then((suggestions) => {
          if (suggestions.length) {
            const newChars: Character[] = suggestions.map((s) => ({
              id: uid(),
              name: s.name,
              avatar: '',
              persona: s.persona,
              greeting: s.greeting,
              signature: s.signature,
              imagePromptTemplate: '',
              createdAt: Date.now(),
            }));
            onNpcDetected(newChars);
          }
        }).catch(() => {});
      }

      const otherNames = existingNames.filter((n) => n !== char.name);
      if (otherNames.length) {
        detectPlotEvents(api, char.name, recentText, otherNames).then((events) => {
          if (events.length) {
            const storyEvts: StoryEvent[] = events.map((e) => {
              const target = characters.find((c) => c.name === e.targetName);
              return {
                id: uid(),
                characterId: target?.id ?? '',
                sourceThreadId: thread.id,
                sourceCharName: char.name,
                summary: e.summary,
                ts: Date.now(),
              };
            }).filter((e) => e.characterId);
            if (storyEvts.length) onPlotEvents(storyEvts);
          }
        }).catch(() => {});
      }
    } catch (e) {
      onSend([...next, { id: uid(), role: 'assistant', content: `（出错了：${(e as Error).message}）`, ts: Date.now() }]);
    } finally {
      setLoading(false);
      setThinkingMsg(null);
    }
  };

  const sendActive = async (directive: string, localUserActionText?: string) => {
    if (loading) return;
    setLoading(true);
    setThinkingMsg('对方正在输入…');
    
    let next = [...thread.messages];
    if (localUserActionText) {
      const userMsg: ChatMessage = { id: uid(), role: 'user', content: localUserActionText, ts: Date.now() };
      next = [...next, userMsg];
      onSend(next);
    }
    
    try {
      const minReplies = char.replyMinCount ?? 1;
      const maxReplies = char.replyMaxCount ?? 1;
      const clampedMin = Math.max(1, minReplies);
      const clampedMax = Math.max(clampedMin, maxReplies);
      const totalReplies = clampedMin + Math.floor(Math.random() * (clampedMax - clampedMin + 1));

      let currentMsgs = [...next];

      for (let i = 0; i < totalReplies; i++) {
        if (i > 0) {
          setThinkingMsg('对方正在输入…');
          await new Promise((resolve) => setTimeout(resolve, 800));
        }

        const sysInstruction = totalReplies > 1
          ? `\n\n[多条回复机制]
你在这轮对话中正在进行多条连发回复。总条数为 ${totalReplies} 条。
当前正在发送第 ${i + 1} 条。
${i + 1 < totalReplies 
  ? '这是连发回复的中间条目，请只说其中一部分内容，绝对不要把所有话一次性说完！保持口语化，像在发微信一样，短小精悍，剩下的在下一条消息中继续发。不要重复已发送的内容。' 
  : '这是连发回复的最后一条，请结束你本次的全部表达并收尾。'}`
          : '';

        const history: ChatMsg[] = [
          { role: 'system', content: buildSystem() + `\n\n[系统提示：这是一个特殊的「主动互动」事件。指令：${directive}]` + sysInstruction },
          ...currentMsgs.map((m) => ({ role: m.role, content: m.content } as ChatMsg)),
        ];

        const rich = await callChatRich(api.chat, history, { temperature: 0.9, maxTokens: 800 });
        const assistantMsg: ChatMessage = {
          id: uid(),
          role: 'assistant',
          content: rich.content,
          innerThought: rich.innerThought,
          ts: Date.now(),
        };

        currentMsgs = [...currentMsgs, assistantMsg];
        onSend(currentMsgs);

        // Media generation
        const media: MessageMedia[] = [];
        try {
          if (rich.sendImage && rich.imagePrompt) {
            const appearance = char.imagePromptTemplate ? `${char.imagePromptTemplate}, ` : '';
            const imgUrl = await generateImage(api.image, appearance + rich.imagePrompt, { faceRef: char.faceRef });
            media.push({ kind: 'image', url: imgUrl });
          }
        } catch { /* image optional */ }
        try {
          if (rich.sendVoice && rich.voiceText) {
            const { url, duration } = await textToSpeech(api.voice, rich.voiceText);
            media.push({ kind: 'voice', url, duration, text: rich.voiceText });
          }
        } catch { /* voice optional */ }
        if (media.length) {
          const mediaMsg: ChatMessage = { id: uid(), role: 'assistant', content: '', ts: Date.now(), media };
          currentMsgs = [...currentMsgs, mediaMsg];
          onSend(currentMsgs);
        }
      }
    } catch (e) {
      onSend([...next, { id: uid(), role: 'assistant', content: `（互动出错了：${(e as Error).message}）`, ts: Date.now() }]);
    } finally {
      setLoading(false);
      setThinkingMsg(null);
    }
  };

  const startLongPress = (m: ChatMessage) => {
    cancelLongPress();
    longPressTimer.current = setTimeout(() => {
      setActiveMessageMenu(m);
    }, 500);
  };
  const cancelLongPress = () => { if (longPressTimer.current) clearTimeout(longPressTimer.current); };

  const unconsumedEvents = storyEvents.filter((e) => !e.consumed);
  const displayTitle = thread.charAltName ? `${thread.charAltName} (试探小号)` : char.name;

  return (
    <AppScreen title={displayTitle} onBack={onBack} noPad right={<button onClick={() => setShowConfigModal(true)} className="tap txt-dim cursor-pointer" title="角色设置"><Settings size={18} /></button>}>
      {unconsumedEvents.length > 0 && (
        <div className="px-4 py-2 text-[11px] txt-accent glass border-b border-[var(--border)] flex items-center gap-1.5 shrink-0">
          <Sparkles size={12} /> {unconsumedEvents.length} 条新剧情线索已感知
        </div>
      )}
      <div className="flex flex-col h-full overflow-hidden">
        <div className="flex-1 overflow-y-auto no-scrollbar px-4 py-3 space-y-3">
          {thread.messages.map((m) => (
            <div key={m.id} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div
                onPointerDown={() => startLongPress(m)}
                onPointerUp={cancelLongPress}
                onPointerLeave={cancelLongPress}
                className={`max-w-[78%] space-y-2 ${m.role === 'user' ? 'items-end' : 'items-start'} flex flex-col relative group`}
              >
                {m.content && (
                  <div className="flex flex-col gap-1 items-start w-full relative">
                    <div
                      className={`px-3.5 py-2.5 rounded-2xl text-[14px] leading-relaxed ${m.role === 'user' ? 'rounded-br-md text-white font-medium' : 'glass rounded-bl-md'}`}
                      style={m.role === 'user' ? { background: 'var(--accent)', color: 'var(--bg)' } : undefined}
                    >
                      {m.content}
                    </div>

                    {/* Desktop Hover Action Trigger (Hidden by default, shown on hover) */}
                    <button
                      type="button"
                      onClick={() => setActiveMessageMenu(m)}
                      className="absolute top-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity bg-neutral-800 hover:bg-neutral-700 text-neutral-400 w-6 h-6 rounded-full flex items-center justify-center cursor-pointer shadow-lg z-10"
                      style={m.role === 'user' ? { left: '-30px' } : { right: '-30px' }}
                      title="消息选项"
                    >
                      <MoreHorizontal size={13} />
                    </button>

                    {/* Inline translation display */}
                    {translations[m.id] && showTranslation[m.id] && (
                      <div className="px-3 py-1.5 rounded-xl text-[12px] bg-indigo-500/10 border border-indigo-500/15 text-indigo-200 leading-relaxed max-w-full animate-fade-in mt-1 select-text">
                        <div className="text-[10px] text-indigo-400 font-bold mb-0.5 flex items-center gap-1">
                          <span>🌐 翻译 / Translation</span>
                        </div>
                        {translations[m.id]}
                      </div>
                    )}
                  </div>
                )}
                {m.media?.map((md, i) => <MediaBubble key={i} media={md} />)}
              </div>
            </div>
          ))}
          {loading && (
            <div className="flex justify-start">
              <div className="glass rounded-2xl rounded-bl-md px-3.5 py-3 flex items-center gap-1">
                {[0,1,2].map((i) => <span key={i} className="w-1.5 h-1.5 rounded-full bg-current txt-faint animate-pulse-soft" style={{ animationDelay: `${i*0.2}s` }} />)}
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>
        <div className="px-3 py-1.5 border-t border-[var(--border)] flex items-center gap-2 overflow-x-auto no-scrollbar bg-neutral-900/30 shrink-0">
          <button 
            type="button"
            onClick={() => setShowGearShift(true)}
            className="px-2.5 py-1 rounded-full text-[11px] font-bold flex items-center gap-1 shrink-0 select-none transition-all duration-300 cursor-pointer"
            style={{ 
              background: activeInteractEnabled === false ? 'var(--icon-bg)' : 'var(--icon-bg-active)',
              color: activeInteractEnabled === false ? 'var(--text-faint)' : 'var(--accent)'
            }}
          >
            ⚡ 主动互动: {activeInteractEnabled === false ? '已关' : activeInteractMode === 'auto' ? '自动挡' : '手动挡'}
          </button>

          {thread.messages.some((m) => m.role === 'assistant') && (
            <button
              type="button"
              onClick={reroll}
              disabled={loading}
              className="px-2.5 py-1 rounded-full text-[11px] font-bold flex items-center gap-1 shrink-0 select-none transition-all duration-300 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 hover:bg-emerald-500/20 active:scale-95 disabled:opacity-40 cursor-pointer"
            >
              🔄 重roll
            </button>
          )}

          {activeInteractEnabled !== false && (
            <>
              <button 
                type="button"
                onClick={() => sendActive('用户刚刚拍了拍你，请根据你的人设，以你独特的风格拍回去或说点什么。也可以选择发张生活照或者发段语音。', `我 👏 拍了拍 ${thread.charAltName || char.name}`)} 
                className="px-2.5 py-1 rounded-full text-[11px] glass txt-dim hover:txt-accent transition-colors shrink-0"
              >
                👏 拍一拍
              </button>
              <button 
                type="button"
                onClick={() => sendActive('用户希望你主动。请完全由你主动开启一个新话题，聊聊你的最新烦恼、趣事、秘密，或者你脑子里正想着什么。也可以主动发照片或语音。')} 
                className="px-2.5 py-1 rounded-full text-[11px] glass txt-dim hover:txt-accent transition-colors shrink-0"
              >
                🔮 主动搭讪
              </button>
              <button 
                type="button"
                onClick={() => sendActive('用户想看你的自拍/照片。请配合，写一个详细的英文绘图提示词描述你自己的肖像，并且 sendImage 必须设为 true。')} 
                className="px-2.5 py-1 rounded-full text-[11px] glass txt-dim hover:txt-accent transition-colors shrink-0"
              >
                📸 发自拍
              </button>
              <button 
                type="button"
                onClick={() => sendActive('用户想听你的声音。请配合，写下你要发的声音文本，并且 sendVoice 必须设为 true。')} 
                className="px-2.5 py-1 rounded-full text-[11px] glass txt-dim hover:txt-accent transition-colors shrink-0"
              >
                🎙️ 发语音
              </button>
            </>
          )}
        </div>
        <div className="px-3 py-2 border-t border-[var(--border)] flex items-center gap-2 shrink-0 bg-neutral-950/20">
          <button 
            type="button"
            onClick={() => setShowStickers(!showStickers)}
            className={`tap w-10 h-10 rounded-full flex items-center justify-center shrink-0 transition-colors ${showStickers ? 'text-amber-400 bg-white/5' : 'text-neutral-400 hover:text-neutral-200'}`}
          >
            <Smile size={20} />
          </button>
          
          <input 
            value={input} 
            onChange={(e) => {
              setInput(e.target.value);
              if (showStickers) setShowStickers(false);
            }} 
            onKeyDown={(e) => e.key === 'Enter' && send()} 
            placeholder={`对 ${thread.charAltName || char.name} 说…`} 
            className="flex-1 glass rounded-full px-4 h-10 text-[14px] outline-none bg-transparent placeholder:text-[var(--text-faint)]" 
          />
          <button onClick={send} disabled={loading || !input.trim()} className="tap w-10 h-10 rounded-full flex items-center justify-center disabled:opacity-40 shrink-0" style={{ background: 'var(--accent)', color: 'var(--bg)' }}><Send size={18} /></button>
        </div>

        {showStickers && (
          <div className="border-t border-[var(--border)] bg-neutral-950/75 h-[230px] flex flex-col shrink-0 animate-fade-in text-left">
            {/* Expression Items Grid */}
            <div className="flex-1 overflow-y-auto p-3 no-scrollbar">
              {connectedPacks.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-center gap-1.5 p-4">
                  <Smile size={24} className="text-neutral-500" />
                  <div className="text-[12px] font-bold text-neutral-400">当前角色未关联任何表情包</div>
                  <p className="text-[10px] text-neutral-500 max-w-[280px] leading-relaxed">
                    在右上角设置「对话设置」或前往「个人中心 - 本地资源 - 自定义表情包」创建并关联此角色吧！
                  </p>
                </div>
              ) : (
                (() => {
                  const currentPack = connectedPacks.find(p => p.id === (selectedPackTabId || connectedPacks[0].id)) || connectedPacks[0];
                  if (!currentPack || currentPack.expressions.length === 0) {
                    return (
                      <div className="h-full flex flex-col items-center justify-center text-center text-neutral-500 text-[11px] p-4 gap-1">
                        <Smile size={20} />
                        <span>此表情包空空如也</span>
                        <span className="text-[9.5px] text-neutral-600">前往「个人中心 - 本地资源」批量导入表情图片吧！</span>
                      </div>
                    );
                  }
                  return (
                    <div className="grid grid-cols-5 gap-2">
                      {currentPack.expressions.map((ex) => (
                        <button
                          key={ex.id}
                          onClick={() => sendSticker(ex.url)}
                          className="tap aspect-square rounded-xl p-1 bg-neutral-900/30 hover:bg-white/5 border border-white/5 flex flex-col items-center justify-center overflow-hidden transition-all cursor-pointer"
                          title={ex.name}
                        >
                          <img src={ex.url} alt="" className="w-full h-full object-contain" />
                        </button>
                      ))}
                    </div>
                  );
                })()
              )}
            </div>

            {/* Pack Tabs at the bottom */}
            {connectedPacks.length > 0 && (
              <div className="h-11 bg-neutral-900/60 border-t border-[var(--border)] flex items-center px-2 gap-1.5 shrink-0 overflow-x-auto no-scrollbar">
                {connectedPacks.map((p) => {
                  const activeTabId = selectedPackTabId || connectedPacks[0].id;
                  const isSelected = p.id === activeTabId;
                  const cover = p.expressions?.[0]?.url;
                  return (
                    <button
                      key={p.id}
                      onClick={() => setSelectedPackTabId(p.id)}
                      className={`h-8 px-2.5 rounded-lg flex items-center gap-1.5 transition-all text-[11px] font-bold shrink-0 ${
                        isSelected 
                          ? 'bg-[var(--accent)] text-[var(--bg)]' 
                          : 'bg-white/5 hover:bg-white/10 text-neutral-300'
                      }`}
                    >
                      {cover ? (
                        <img src={cover} alt="" className="w-4.5 h-4.5 object-cover rounded" />
                      ) : (
                        <Smile size={12} />
                      )}
                      <span className="truncate max-w-[70px]">{p.name}</span>
                    </button>
                  );
                })}
              </div>
            )}
          </div>
        )}
      </div>

      {thinkingMsg && thinkingMsg !== '对方正在输入…' && (
        <div className="absolute inset-0 z-50 flex items-center justify-center p-8" onClick={() => setThinkingMsg(null)}>
          <div className="absolute inset-0 bg-black/60 animate-fade-in" />
          <div className="relative glass-strong rounded-2xl p-5 max-w-[88%] animate-sheet-up border border-[var(--border)] shadow-xl">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2 txt-accent text-[13px] font-semibold"><Eye size={15} /> 悄悄看 {thread.charAltName || char.name} 的心声</div>
              <button onClick={() => setThinkingMsg(null)} className="tap txt-dim"><X size={16} /></button>
            </div>
            <div className="text-[14px] leading-relaxed txt-dim">{thinkingMsg}</div>
          </div>
        </div>
      )}

      {activeMessageMenu && (
        <Modal
          open={!!activeMessageMenu}
          onClose={() => setActiveMessageMenu(null)}
          title="消息选项"
        >
          <div className="space-y-3.5 p-1 pb-4">
            {activeMessageMenu.content && (
              <div className="glass p-3 rounded-xl text-xs txt-dim select-text max-h-24 overflow-y-auto break-all">
                {activeMessageMenu.content}
              </div>
            )}
            
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={async () => {
                  const txt = activeMessageMenu.content;
                  setActiveMessageMenu(null);
                  if (txt) {
                    try {
                      await navigator.clipboard.writeText(txt);
                    } catch {
                      // fallback
                    }
                  }
                }}
                className="tap h-12 rounded-xl glass flex flex-col items-center justify-center gap-1 text-[13px] font-medium"
              >
                <span className="text-[var(--accent)] text-sm">📋</span>
                <span>复制文本</span>
              </button>

              {activeMessageMenu.role === 'assistant' && activeMessageMenu.content && (
                <button
                  type="button"
                  onClick={() => {
                    const m = activeMessageMenu;
                    setActiveMessageMenu(null);
                    toggleTranslate(m);
                  }}
                  className="tap h-12 rounded-xl glass flex flex-col items-center justify-center gap-1 text-[13px] font-medium"
                >
                  <span className="text-indigo-400 text-sm">🌐</span>
                  <span>{showTranslation[activeMessageMenu.id] ? '隐藏翻译' : '翻译消息'}</span>
                </button>
              )}

              {activeMessageMenu.role === 'assistant' && (
                <button
                  type="button"
                  onClick={() => {
                    setActiveMessageMenu(null);
                    reroll();
                  }}
                  className="tap h-12 rounded-xl glass flex flex-col items-center justify-center gap-1 text-[13px] font-medium col-span-2 border border-emerald-500/20 text-emerald-300"
                >
                  <span className="text-emerald-400 text-sm">🔄</span>
                  <span>重新生成回复 (重roll)</span>
                </button>
              )}

              {activeMessageMenu.innerThought && (
                <button
                  type="button"
                  onClick={() => {
                    const thought = activeMessageMenu.innerThought;
                    setActiveMessageMenu(null);
                    setThinkingMsg(thought!);
                  }}
                  className="tap h-12 rounded-xl glass flex flex-col items-center justify-center gap-1 text-[13px] font-medium col-span-2"
                >
                  <span className="text-yellow-400 text-sm">💡</span>
                  <span>查看AI内心活动</span>
                </button>
              )}

              <button
                type="button"
                onClick={() => {
                  const m = activeMessageMenu;
                  setActiveMessageMenu(null);
                  if (confirm('确定删除此条消息？此操作无法撤销。')) {
                    const nextMsgs = thread.messages.filter((x) => x.id !== m.id);
                    onSend(nextMsgs);
                  }
                }}
                className="tap h-12 rounded-xl bg-red-500/10 hover:bg-red-500/20 text-red-400 flex flex-col items-center justify-center gap-1 text-[13px] font-medium col-span-2"
              >
                <span className="text-red-400 text-sm">🗑️</span>
                <span>删除消息</span>
              </button>
            </div>
          </div>
        </Modal>
      )}

      {showGearShift && (
        <div className="absolute inset-0 z-[100] flex items-end justify-center">
          <div className="absolute inset-0 bg-neutral-950/80 backdrop-blur-sm animate-fade-in" onClick={() => setShowGearShift(false)} />
          
          <div className="relative w-full max-w-md bg-neutral-900 border-t border-neutral-800 rounded-t-[32px] p-5 pb-8 flex flex-col items-center animate-sheet-up select-none shadow-[0_-12px_40px_rgba(0,0,0,0.6)]">
            <div className="w-12 h-1 bg-neutral-700/60 rounded-full mb-4" />
            
            <div className="w-full flex items-center justify-between mb-4">
              <div>
                <h3 className="text-sm font-bold text-neutral-100 flex items-center gap-1.5">
                  ⚙️ 变速器控制台 (Transmission Console)
                </h3>
                <p className="text-[10px] text-neutral-400 mt-0.5">控制 {thread.charAltName || char.name} 的主动搭讪与互动频率</p>
              </div>
              <button 
                type="button"
                onClick={() => setShowGearShift(false)} 
                className="w-6 h-6 rounded-full bg-neutral-800 hover:bg-neutral-750 text-neutral-400 hover:text-neutral-200 flex items-center justify-center text-xs font-bold transition-colors cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="w-full grid grid-cols-5 gap-3 items-center bg-neutral-950/40 p-3.5 rounded-2xl border border-neutral-850 my-1">
              <div className="col-span-2 space-y-3.5 text-right pr-1">
                <button 
                  type="button"
                  onClick={() => {
                    if (shifterLocked) {
                      setLockWarning(true);
                      setTimeout(() => setLockWarning(false), 2000);
                      return;
                    }
                    if (onUpdateSettings) onUpdateSettings({ activeInteractEnabled: false });
                  }}
                  className={`block w-full text-right py-1.5 px-2 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    activeInteractEnabled === false 
                      ? 'text-rose-400 bg-rose-500/10 border-r-2 border-rose-500' 
                      : 'text-neutral-500 hover:text-neutral-400'
                  }`}
                >
                  P 挡 · 已关 (Park)
                </button>
                <button 
                  type="button"
                  onClick={() => {
                    if (shifterLocked) {
                      setLockWarning(true);
                      setTimeout(() => setLockWarning(false), 2000);
                      return;
                    }
                    if (onUpdateSettings) onUpdateSettings({ activeInteractEnabled: true, activeInteractMode: 'manual' });
                  }}
                  className={`block w-full text-right py-1.5 px-2 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    activeInteractEnabled !== false && activeInteractMode === 'manual'
                      ? 'text-amber-400 bg-amber-500/10 border-r-2 border-amber-500' 
                      : 'text-neutral-500 hover:text-neutral-400'
                  }`}
                >
                  M 挡 · 手动 (Manual)
                </button>
                <button 
                  type="button"
                  onClick={() => {
                    if (shifterLocked) {
                      setLockWarning(true);
                      setTimeout(() => setLockWarning(false), 2000);
                      return;
                    }
                    if (onUpdateSettings) onUpdateSettings({ activeInteractEnabled: true, activeInteractMode: 'auto' });
                  }}
                  className={`block w-full text-right py-1.5 px-2 rounded-lg text-[11px] font-bold transition-all cursor-pointer ${
                    activeInteractEnabled !== false && activeInteractMode === 'auto'
                      ? 'text-emerald-400 bg-emerald-500/10 border-r-2 border-emerald-500' 
                      : 'text-neutral-500 hover:text-neutral-400'
                  }`}
                >
                  D 挡 · 自动 (Drive)
                </button>
              </div>

              <div className="col-span-1 flex justify-center relative h-40 bg-neutral-950 rounded-2xl border border-neutral-850 p-2 overflow-visible shadow-inner">
                <div className="absolute w-2 h-[75%] bg-neutral-900 border border-neutral-855 left-1/2 -translate-x-1/2 top-5 rounded-full" />
                
                <div 
                  className="absolute left-1/2 -translate-x-1/2 transition-all duration-300 ease-out flex flex-col items-center z-10"
                  style={{ 
                    top: activeInteractEnabled === false ? '15%' : activeInteractMode === 'auto' ? '70%' : '42%',
                    transform: 'translate(-50%, -40%)'
                  }}
                >
                  <div className="w-7 h-7 rounded-full bg-neutral-900 border border-neutral-800 shadow-md flex items-center justify-center relative overflow-hidden">
                    <div className="w-3.5 h-3.5 bg-neutral-950 rounded-full" />
                  </div>

                  <div className="w-1 h-5 bg-gradient-to-r from-neutral-600 via-neutral-400 to-neutral-600 border-x border-neutral-700" />

                  <div className="relative w-11 h-9 rounded-xl bg-gradient-to-b from-neutral-800 to-neutral-950 border border-neutral-750 shadow-xl flex flex-col items-center justify-center p-0.5 cursor-pointer hover:border-neutral-600 transition-all">
                    <div className="text-[7px] font-mono font-bold text-neutral-500 leading-none">
                      P-M-D
                    </div>
                    <div className="text-[9px] font-mono font-bold text-neutral-200 mt-0.5 leading-none bg-neutral-900/80 px-1 rounded">
                      {activeInteractEnabled === false ? 'P' : activeInteractMode === 'auto' ? 'D' : 'M'}
                    </div>

                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        setShifterLocked(!shifterLocked);
                      }}
                      className={`absolute -right-2.5 top-1/2 -translate-y-1/2 w-5.5 h-5.5 rounded-full border flex items-center justify-center shadow-lg transition-all active:scale-90 cursor-pointer ${
                        shifterLocked 
                          ? 'bg-rose-500 border-rose-400 text-white shadow-rose-500/50' 
                          : 'bg-neutral-700 border-neutral-600 text-neutral-300'
                      }`}
                      title={shifterLocked ? '自锁已启用 (锁定挡位)' : '自锁已解除 (可以换挡)'}
                    >
                      <span className="text-[9px] font-bold">{shifterLocked ? '🔒' : '🔓'}</span>
                    </button>
                  </div>
                </div>
              </div>

              <div className="col-span-2 space-y-3.5 text-left pl-1">
                <div className="h-8 flex flex-col justify-center">
                  <span className="text-[9.5px] text-neutral-400 leading-tight">驻车：AI绝不主动发信。</span>
                </div>
                <div className="h-8 flex flex-col justify-center">
                  <span className="text-[9.5px] text-neutral-400 leading-tight">手动：可手动点击触发搭讪。</span>
                </div>
                <div className="h-8 flex flex-col justify-center">
                  <span className="text-[9.5px] text-neutral-400 leading-tight">自动：AI定时主动联络。</span>
                </div>
              </div>
            </div>

            <div className="w-full h-7 flex items-center justify-center mt-1">
              {lockWarning ? (
                <div className="text-[10px] font-bold text-rose-400 bg-rose-500/10 px-2.5 py-0.5 rounded-full border border-rose-500/20 animate-bounce">
                  ⚠️ 换挡锁定中！请先点击排挡头上的【自锁开关 🔒/🔓】
                </div>
              ) : (
                <div className="text-[10.5px] text-neutral-400">
                  {shifterLocked ? (
                    <span className="text-neutral-500">🔒 自锁已启用。换挡前请点击右侧自锁开关</span>
                  ) : (
                    <span className="text-emerald-400 font-medium">🔓 自锁已释放。点击左侧档位名称直接换挡</span>
                  )}
                </div>
              )}
            </div>

            <div className="w-full bg-neutral-950/20 p-2.5 rounded-xl border border-neutral-850 mt-2 text-left">
              <div className="text-[10px] font-semibold text-neutral-300 flex items-center gap-1">
                💡 控制台使用说明
              </div>
              <ol className="text-[9.5px] text-neutral-400 list-decimal list-inside space-y-0.5 mt-0.5">
                <li>换挡前，先点击排挡头右侧【自锁开关 🔒】解除自锁（变为绿色 🔓）；</li>
                <li>再点击左侧的【P 挡】/【M 挡】/【D 挡】调整互动挡位；</li>
                <li>换挡后，可再次点击【自锁开关 🔓】锁定当前挡位，防止误触。</li>
              </ol>
            </div>
          </div>
        </div>
      )}

      {showConfigModal && (
        <Modal open={showConfigModal} onClose={() => setShowConfigModal(false)} title={`${char.name} 对话设置`}>
          <div className="space-y-4 text-left p-1">
            
            {/* Word Limits */}
            <div>
              <label className="block text-[12px] font-bold text-neutral-400 mb-1.5">
                每次回复字数限制 (Words per Reply)
              </label>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-[10px] text-neutral-500 block mb-1">下限 (最少字数)</span>
                  <input
                    type="number"
                    min="0"
                    placeholder="不限"
                    value={minWords}
                    onChange={(e) => setMinWords(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <span className="text-[10px] text-neutral-500 block mb-1">上限 (最多字数)</span>
                  <input
                    type="number"
                    min="0"
                    placeholder="不限"
                    value={maxWords}
                    onChange={(e) => setMaxWords(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>
            </div>

            {/* Response Counts */}
            <div>
              <label className="block text-[12px] font-bold text-neutral-400 mb-1.5">
                每次连发回复条数 (Consecutive Replies)
              </label>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <span className="text-[10px] text-neutral-500 block mb-1">最少条数</span>
                  <input
                    type="number"
                    min="1"
                    placeholder="1"
                    value={minCount}
                    onChange={(e) => setMinCount(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
                <div>
                  <span className="text-[10px] text-neutral-500 block mb-1">最多条数</span>
                  <input
                    type="number"
                    min="1"
                    placeholder="1"
                    value={maxCount}
                    onChange={(e) => setMaxCount(e.target.value)}
                    className="w-full bg-neutral-900 border border-neutral-800 rounded-xl px-3 py-2 text-sm text-neutral-200 focus:outline-none focus:border-indigo-500"
                  />
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="pt-3 flex gap-3">
              <button
                type="button"
                onClick={() => setShowConfigModal(false)}
                className="flex-1 bg-neutral-800 hover:bg-neutral-750 text-neutral-300 py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                取消
              </button>
              <button
                type="button"
                onClick={handleSaveConfig}
                className="flex-1 bg-indigo-600 hover:bg-indigo-500 text-white py-2.5 rounded-xl text-xs font-bold transition-all cursor-pointer"
              >
                保存设置
              </button>
            </div>

            {/* Delete All Data Option */}
            <div className="border-t border-neutral-800/60 pt-4 mt-2">
              <div className="text-[11px] text-neutral-500 mb-2">
                危险操作区 (Danger Zone)
              </div>
              <button
                type="button"
                onClick={() => setShowDeleteConfirm(true)}
                className="w-full bg-red-500/10 hover:bg-red-500/20 text-red-400 border border-red-500/20 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Trash2 size={13} /> 删除全部关于此角色的数据
              </button>
              <p className="text-[9.5px] text-neutral-500 mt-1.5 text-center leading-relaxed">
                删除该角色设定、全部历史聊天记录、短信线程以及相关数据。此操作不可撤销。
              </p>
            </div>

          </div>
        </Modal>
      )}

      {showDeleteConfirm && (
        <Confirm
          open={showDeleteConfirm}
          title="彻底删除数据"
          message={`您确定要彻底删除角色「${char.name}」及与之相关的所有对话记录、短信和其他全部数据吗？此操作将不可撤销！`}
          confirmText="彻底删除"
          cancelText="返回"
          danger
          onConfirm={handleDeleteAllData}
          onCancel={() => setShowDeleteConfirm(false)}
        />
      )}
    </AppScreen>
  );
}

function MediaBubble({ media }: { key?: any; media: MessageMedia }) {
  const [playing, setPlaying] = useState(false);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  if (media.kind === 'image') {
    if (media.isSticker) {
      return (
        <div className="max-w-[140px] overflow-hidden p-1 bg-transparent">
          <img src={media.url} alt="" referrerPolicy="no-referrer" className="w-full h-auto max-h-[140px] object-contain rounded-lg animate-fade-in" />
        </div>
      );
    }
    return (
      <div className="rounded-2xl overflow-hidden max-w-[220px] glass rounded-bl-md p-1">
        <img src={media.url} alt="" referrerPolicy="no-referrer" className="w-full rounded-xl object-cover" />
      </div>
    );
  }
  const toggle = () => {
    if (!audioRef.current) {
      audioRef.current = new Audio(media.url);
      audioRef.current.addEventListener('ended', () => setPlaying(false));
    }
    if (playing) { audioRef.current.pause(); setPlaying(false); }
    else { audioRef.current.play(); setPlaying(true); }
  };
  return (
    <button onClick={toggle} className="tap flex items-center gap-2 glass rounded-2xl rounded-bl-md px-3.5 py-2.5 min-w-[120px]">
      {playing ? <Pause size={16} className="txt-accent" /> : <Mic size={16} className="txt-accent" />}
      <div className="flex-1 text-left">
        <div className="text-[13px] txt-accent">{playing ? '播放中…' : '语音消息'}</div>
        {media.duration ? <div className="text-[10px] txt-faint">{media.duration}″</div> : null}
      </div>
      <Play size={14} className="txt-dim" />
    </button>
  );
}
