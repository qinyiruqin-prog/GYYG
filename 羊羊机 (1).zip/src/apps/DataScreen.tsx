import { useRef, useState } from 'react';
import { Download, Upload, AlertTriangle, Trash2, Database, Calendar, Clock, RefreshCw } from 'lucide-react';
import { AppScreen } from '../components/AppScreen';
import { ListGroup, Row } from '../components/ui';
import { Confirm, Modal } from '../components/Sheet';
import type { AppSettings, PersistShape } from '../types';
import { exportData, importData, getAutoBackups, saveAutoBackup, deleteAutoBackup } from '../store';
import type { AutoBackupEntry } from '../store';

export function DataScreen({
  state,
  onImport,
  updateSettings,
  onBack,
}: {
  state: PersistShape;
  onImport: (next: PersistShape) => void;
  updateSettings: (patch: Partial<AppSettings>) => void;
  onBack: () => void;
}) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [confirmImport, setConfirmImport] = useState<PersistShape | null>(null);
  const [confirmBackupImport, setConfirmBackupImport] = useState<PersistShape | null>(null);
  const [err, setErr] = useState('');
  const [backups, setBackups] = useState<AutoBackupEntry[]>(() => getAutoBackups());

  const handleFile = async (file?: File) => {
    if (!file) return;
    setErr('');
    try {
      const parsed = await importData(file);
      setConfirmImport(parsed);
    } catch (e) {
      setErr((e as Error).message || '导入失败');
    }
  };

  const handleRestoreBackup = (b: AutoBackupEntry) => {
    try {
      const parsed = JSON.parse(b.data) as PersistShape;
      setConfirmBackupImport(parsed);
    } catch (e) {
      setErr('备份解析失败，可能文件已损坏');
    }
  };

  const handleDeleteBackup = (id: string) => {
    deleteAutoBackup(id);
    setBackups(getAutoBackups());
  };

  const handleManualBackup = () => {
    const success = saveAutoBackup(state);
    if (success) {
      setBackups(getAutoBackups());
      updateSettings({ lastAutoBackupTs: Date.now() });
    } else {
      setErr('备份生成失败，可能是浏览器 localStorage 空间不足。');
    }
  };

  const autoBackupEnabled = state.settings.autoBackupEnabled ?? false;
  const autoBackupFrequency = state.settings.autoBackupFrequency || 'daily';

  const stats = {
    users: state.settings.users.length,
    partitions: state.settings.partitions.length,
    music: state.settings.music.length,
    images: state.settings.albumImages.length,
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  return (
    <AppScreen title="数据备份" onBack={onBack}>
      <div className="text-[12px] txt-faint mb-3 leading-relaxed">
        所有数据保存在本地浏览器中。导出为单个文件用于备份或换设备；导入会覆盖当前数据。
      </div>

      <div className="glass rounded-2xl p-4 mb-4">
        <div className="text-[13px] txt-dim mb-2">当前数据概览</div>
        <div className="grid grid-cols-4 gap-2 text-center">
          <Stat n={stats.users} label="身份" />
          <Stat n={stats.partitions} label="分区" />
          <Stat n={stats.music} label="音乐" />
          <Stat n={stats.images} label="图片" />
        </div>
      </div>

      {/* 自动备份设置 */}
      <div className="glass rounded-2xl p-4 mb-4 space-y-3.5">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <RefreshCw size={17} className="text-indigo-400" />
            <span className="text-[14px] font-medium text-neutral-200">自动备份数据</span>
          </div>
          <button
            type="button"
            onClick={() => updateSettings({ autoBackupEnabled: !autoBackupEnabled })}
            className={`px-3 py-1 rounded-full text-[12px] font-bold transition-all duration-300 ${
              autoBackupEnabled
                ? 'bg-emerald-500/10 border border-emerald-500/20 text-emerald-300'
                : 'bg-neutral-800 border border-neutral-700 text-neutral-400'
            }`}
          >
            {autoBackupEnabled ? '已开启 ON' : '已关闭 OFF'}
          </button>
        </div>

        {autoBackupEnabled && (
          <div className="space-y-3 pt-3 border-t border-neutral-800/50 animate-fade-in">
            {/* 备份频率选择 */}
            <div>
              <div className="text-[12px] txt-dim mb-2 flex items-center gap-1.5">
                <Clock size={13} className="text-neutral-400" />
                <span>自定义备份频率:</span>
              </div>
              <div className="grid grid-cols-4 gap-1.5">
                {(
                  [
                    { key: 'daily', label: '每天' },
                    { key: 'five_days', label: '每五天' },
                    { key: 'half_month', label: '半个月' },
                    { key: 'monthly', label: '每月' },
                  ] as const
                ).map((opt) => (
                  <button
                    key={opt.key}
                    type="button"
                    onClick={() => updateSettings({ autoBackupFrequency: opt.key })}
                    className={`py-1.5 rounded-xl text-[12px] font-medium transition-all ${
                      autoBackupFrequency === opt.key
                        ? 'bg-[var(--accent)] text-[var(--bg)] font-bold'
                        : 'glass text-neutral-400 hover:text-white'
                    }`}
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
            </div>

            {/* 手动触发备份 */}
            <div className="flex items-center justify-between pt-1.5">
              <span className="text-[11px] txt-faint">
                上次备份: {state.settings.lastAutoBackupTs ? new Date(state.settings.lastAutoBackupTs).toLocaleDateString() : '从未备份'}
              </span>
              <button
                type="button"
                onClick={handleManualBackup}
                className="px-3 py-1.5 rounded-xl bg-indigo-500/10 border border-indigo-500/15 text-indigo-300 text-[11px] font-medium hover:bg-indigo-500/25 active:scale-95 transition-all cursor-pointer"
              >
                立即手动生成备份
              </button>
            </div>
          </div>
        )}
      </div>

      {/* 自动备份历史 */}
      {autoBackupEnabled && (
        <div className="glass rounded-2xl p-4 mb-4">
          <div className="text-[13px] txt-dim mb-2.5 flex items-center justify-between">
            <span className="flex items-center gap-1.5">
              <Database size={14} className="text-indigo-400" />
              <span>自动备份记录 ({backups.length}/5)</span>
            </span>
            <span className="text-[11px] txt-faint">浏览器沙盒存储</span>
          </div>

          {backups.length === 0 ? (
            <div className="text-center py-6 text-[12px] txt-faint">
              暂无备份。点击上方手动生成或静候到达频率自动触发。
            </div>
          ) : (
            <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
              {backups.map((b) => (
                <div key={b.id} className="p-2.5 rounded-xl bg-neutral-950/40 border border-neutral-800/40 flex items-center justify-between gap-2">
                  <div className="space-y-0.5">
                    <div className="text-[12px] font-medium text-neutral-200">
                      {new Date(b.ts).toLocaleString('zh-CN', { hour12: false })}
                    </div>
                    <div className="text-[10px] txt-faint">
                      大小: {formatSize(b.size)}
                    </div>
                  </div>

                  <div className="flex items-center gap-1 shrink-0">
                    <button
                      type="button"
                      onClick={() => handleRestoreBackup(b)}
                      className="px-2 py-1 rounded bg-emerald-500/10 hover:bg-emerald-500/20 text-emerald-300 text-[11px] font-medium cursor-pointer transition-colors"
                      title="恢复此备份"
                    >
                      恢复
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        try {
                          const parsed = JSON.parse(b.data) as PersistShape;
                          exportData(parsed);
                        } catch {
                          alert('导出失败');
                        }
                      }}
                      className="px-2 py-1 rounded bg-indigo-500/10 hover:bg-indigo-500/20 text-indigo-300 text-[11px] font-medium cursor-pointer transition-colors"
                      title="导出文件"
                    >
                      导出
                    </button>
                    <button
                      type="button"
                      onClick={() => handleDeleteBackup(b.id)}
                      className="p-1 rounded bg-red-500/10 hover:bg-red-500/20 text-red-400 cursor-pointer transition-colors"
                      title="删除此备份"
                    >
                      <Trash2 size={13} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* 原有数据备份导出导入 */}
      <div className="text-[13px] txt-dim mb-2 px-1">手动导入/导出</div>
      <ListGroup>
        <Row
          label={<span className="flex items-center gap-2"><Download size={17} /> 导出所有数据</span>}
          hint="打包所有角色/聊天/设置并下载为文件"
          onClick={() => exportData(state)}
        />
        <Row
          label={<span className="flex items-center gap-2"><Upload size={17} /> 导入数据文件</span>}
          hint="从导出的备份 .json 文件恢复"
          onClick={() => fileRef.current?.click()}
        />
      </ListGroup>

      {err && (
        <Modal open onClose={() => setErr('')} title="操作失败">
          <div className="text-sm text-center txt-dim p-4">{err}</div>
        </Modal>
      )}

      <input ref={fileRef} type="file" accept="application/json" className="hidden" onChange={(e) => handleFile(e.target.files?.[0])} />

      <Confirm
        open={!!confirmImport}
        title="确认导入"
        message={
          <span className="flex flex-col items-center gap-2 text-center p-2">
            <AlertTriangle size={24} className="text-[var(--warn)]" />
            <span>导入将覆盖当前所有数据，确定继续？</span>
          </span>
        }
        confirmText="覆盖导入"
        danger
        onConfirm={() => { if (confirmImport) onImport(confirmImport); setConfirmImport(null); }}
        onCancel={() => setConfirmImport(null)}
      />

      <Confirm
        open={!!confirmBackupImport}
        title="确认恢复自动备份"
        message={
          <span className="flex flex-col items-center gap-2 text-center p-2">
            <AlertTriangle size={24} className="text-[var(--warn)] animate-pulse" />
            <span>恢复此自动备份将完全覆盖您当前的所有数据。确定继续？</span>
          </span>
        }
        confirmText="确认覆盖恢复"
        danger
        onConfirm={() => {
          if (confirmBackupImport) {
            onImport(confirmBackupImport);
            setConfirmBackupImport(null);
          }
        }}
        onCancel={() => setConfirmBackupImport(null)}
      />
    </AppScreen>
  );
}

function Stat({ n, label }: { n: number; label: string }) {
  return (
    <div>
      <div className="font-title text-2xl txt-accent">{n}</div>
      <div className="text-[11px] txt-faint">{label}</div>
    </div>
  );
}
