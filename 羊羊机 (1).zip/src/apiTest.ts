export type TestStatus = 'idle' | 'testing' | 'ok' | 'fail';

export interface TestResult {
  status: TestStatus;
  message: string;
}

const supabaseUrl = (import.meta.env.VITE_SUPABASE_URL ?? import.meta.env.SUPABASE_URL ?? '') as string;

async function callProxy(cfg: Record<string, string>, mode: 'chat' | 'image' | 'voice'): Promise<TestResult> {
  if (!cfg.baseUrl && mode !== 'voice') return { status: 'fail', message: '请填写接口地址' };
  if (!cfg.baseUrl && mode === 'voice' && cfg.provider === 'custom') return { status: 'fail', message: '请填写接口地址' };

  const base = cfg.baseUrl.replace(/\/+$/, '');

  // 1. ALWAYS try direct client-side fetch first (matching how the application makes direct calls)
  try {
    let testUrl = '';
    let method = 'GET';
    let body: string | undefined = undefined;

    if (mode === 'chat') {
      testUrl = `${base}/chat/completions`;
      method = 'POST';
      body = JSON.stringify({
        model: cfg.model || 'gpt-4o-mini',
        messages: [{ role: 'user', content: 'ping' }],
        max_tokens: 1,
      });
    } else if (mode === 'image') {
      testUrl = `${base}/images/generations`;
      method = 'POST';
      body = JSON.stringify({
        prompt: 'test',
        n: 1,
        size: '256x256',
      });
    } else {
      testUrl = `${base}/audio/speech`;
      method = 'POST';
      body = JSON.stringify({
        model: 'tts-1',
        input: 'test',
        voice: 'alloy',
      });
    }

    const headers: Record<string, string> = {
      'Content-Type': 'application/json',
    };
    if (cfg.apiKey) {
      headers['Authorization'] = `Bearer ${cfg.apiKey}`;
    }

    const res = await fetch(testUrl, {
      method,
      headers,
      body,
    });

    if (res.ok) {
      return { status: 'ok', message: '连接成功 (直接连接)' };
    }

    if (res.status === 401 || res.status === 403) {
      return { status: 'fail', message: `API Key 验证失败 (HTTP ${res.status})` };
    }

    // Some endpoints may return 400/404/405 on empty/invalid parameters but are reachable. Let's fallback to GET /models
    if (res.status === 400 || res.status === 404 || res.status === 405) {
      try {
        const modelsRes = await fetch(`${base}/models`, {
          method: 'GET',
          headers: cfg.apiKey ? { Authorization: `Bearer ${cfg.apiKey}` } : {},
        });
        if (modelsRes.ok) {
          return { status: 'ok', message: '连接成功 (直接连接模型接口)' };
        }
      } catch {}
      return { status: 'ok', message: `服务器可达 (HTTP ${res.status})` };
    }
  } catch (directError) {
    console.warn('Direct connection test failed/blocked, checking proxy:', directError);
    // If no supabaseUrl is configured, return the direct error
    if (!supabaseUrl || !supabaseUrl.startsWith('http')) {
      return {
        status: 'fail',
        message: `直连失败: ${(directError as Error).message} (请检查接口地址或网络。由于浏览器安全限制，如果目标 API 不支持 CORS 跨域请求，可能会导致直连失败。)`
      };
    }
  }

  // 2. Fallback to Supabase Edge Function proxy ONLY if direct connection failed/threw CORS block and proxy is set up
  if (supabaseUrl && supabaseUrl.startsWith('http')) {
    try {
      const fnUrl = `${supabaseUrl}/functions/v1/api-test`;
      const res = await fetch(fnUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ baseUrl: cfg.baseUrl, apiKey: cfg.apiKey, mode }),
      });
      if (!res.ok) return { status: 'fail', message: `代理请求失败 HTTP ${res.status}` };
      
      const contentType = res.headers.get('Content-Type') ?? '';
      if (!contentType.includes('application/json')) {
        const text = await res.text();
        if (text.trim().startsWith('<!')) {
          return { status: 'fail', message: `代理返回了非 JSON 格式的 HTML。请确认您的 API 接口地址与 Key 是否正确。` };
        }
        return { status: 'fail', message: `代理返回格式错误: ${text.slice(0, 100)}` };
      }
      
      const data = await res.json();
      return data.ok
        ? { status: 'ok', message: data.message ?? '连接成功' }
        : { status: 'fail', message: data.message ?? '连接失败' };
    } catch (e) {
      return { status: 'fail', message: `代理连接失败: ${(e as Error).message}` };
    }
  }

  return { status: 'fail', message: '未配置有效的接口测试通道' };
}

export async function testChat(cfg: Record<string, string>): Promise<TestResult> {
  return callProxy(cfg, 'chat');
}

export async function testImage(cfg: Record<string, string>): Promise<TestResult> {
  return callProxy(cfg, 'image');
}

export async function testVoice(cfg: Record<string, string>): Promise<TestResult> {
  if (cfg.provider === 'minimax') {
    if (!cfg.apiKey) return { status: 'fail', message: '请填写 MiniMax API Key' };
    return { status: 'ok', message: '已保存 MiniMax 配置（联网时调用）' };
  }
  return callProxy(cfg, 'voice');
}
